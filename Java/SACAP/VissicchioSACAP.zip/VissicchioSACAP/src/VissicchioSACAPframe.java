import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTabbedPane;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JFormattedTextField;
import java.awt.Choice;
import java.awt.Label;
import java.awt.List;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JSpinner;
import javax.swing.JScrollBar;
import javax.swing.JTable;
import javax.swing.SpinnerDateModel;
import java.util.Date;
import java.util.Calendar;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import java.awt.Color;
import javax.swing.JCheckBox;
import javax.swing.SpinnerNumberModel;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.MaskFormatter;

import java.beans.PropertyChangeListener;
import java.text.NumberFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.beans.PropertyChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JList;
import javax.swing.AbstractListModel;
import javax.swing.JTextArea;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Component;
import javax.swing.Box;
import javax.swing.JSeparator;
import java.text.Format;

public class VissicchioSACAPframe extends JFrame {

	private JPanel contentPane;
	
	NumberFormat numberFormat = NumberFormat.getNumberInstance();
	
	private final JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
	private final JPanel page1 = new JPanel();
	private final JPanel page3 = new JPanel();
	private final JLabel lblTitle = new JLabel("<html>\r\nThe Salvation Army, Virginia Peninsula Corps\r\n<br>\r\n2013 Christmas Assistance Application\r\n</html>\r\n");
	private final JLabel lblName = new JLabel("Applicant's Name:");
	private final JLabel lblSSN = new JLabel("Last 4 Digits of SSN:");
	
	private final JFormattedTextField ssnFTF = new JFormattedTextField();
	MaskFormatter ssnMask = createFormatter("####");
	
	private final JLabel lblBirthdate = new JLabel("Birth Date: ");
	private final JTextField lastNameTF = new JTextField();
	private final JTextField firstNameTF = new JTextField();
	private final JSpinner spinner = new JSpinner();
	private final JLabel lblMarital = new JLabel("Marital Status:");
	private final JComboBox maritalCB = new JComboBox();
	private final JLabel lblRace = new JLabel("Race:");
	private final JComboBox raceCB = new JComboBox();
	private final JLabel lblGender = new JLabel("Gender:");
	private final JComboBox genderCB = new JComboBox();
	private final JLabel lblPhoneNum = new JLabel("Phone Number:");
	
	private final JFormattedTextField phoneFTF = new JFormattedTextField();
	MaskFormatter phoneMask = createFormatter("(###)###-####");
	
	private final JLabel lblStreetAddress = new JLabel("Street Address:");
	private final JLabel lblCity = new JLabel("City:");
	private final JLabel lblState = new JLabel("State:");
	private final JLabel lblZipcode = new JLabel("Zip Code:");
	private final JFormattedTextField streetFTF = new JFormattedTextField();
	private final JTextField cityTF = new JTextField();
	private final JTextField stateTF = new JTextField();
	
	private final JFormattedTextField zipcodeFTF = new JFormattedTextField();
	MaskFormatter zipcodeMask = createFormatter("#####");
	
	private final JMenuBar menuBar = new JMenuBar();
	private final JMenu mnFile = new JMenu("File");
	private final JMenuItem mnStart = new JMenuItem("Start New Application");
	private final JMenuItem mntmExit = new JMenuItem("Exit");
	private final JMenu mnHelp = new JMenu("Help");
	private final JLabel lblChristmasAssistance = new JLabel("<html>\r\nHave you applied for Christmas assistance\r\n<br>\r\n with any other agency, church or organization?\r\n</html>");
	private final JComboBox christmasAssistanceCB = new JComboBox();
	private final JLabel lblNewLabel = new JLabel("<html>\r\nI understand that completing this application <br> \r\ndoes not guarantee the receipt of any gifts <br> \r\nor food vouchers, and that the quality and <br>\r\nquantity of gifts is dependent upon the <br> generosity of donors.\r\nI hereby give <br> permission to release this information to <br> another    \r\n group or person for assistance or<br> verification of information.\r\n</html>");
	private final JCheckBox cbSignature = new JCheckBox("Digital Signature");
	private final JScrollPane scrollPane = new JScrollPane();
	private final JLabel lblNameP4 = new JLabel("Applicant's Name:");
	private final JTextField lastNameP4TF = new JTextField();
	private final JTextField firstNameP4TF = new JTextField();
	private final JLabel lblSSNP4 = new JLabel("Last 4 Digits of SSN:");
	private final JFormattedTextField ssnFTFP4 = new JFormattedTextField();
	private final JLabel lblPage3 = new JLabel("Page 3");
	private final JLabel lblAppChildren = new JLabel("APPLICANT\u2019S CHILDREN (List all children 13 and under) (provide proof of parenthood/guardianship and each child\u2019s DOB)\r\n");
	private final JLabel lblPage1 = new JLabel("Page 1");
	private final JPanel page2 = new JPanel();
	private final JLabel lblNameP3 = new JLabel("Applicant's Name:");
	private final JTextField lastNameP3TF = new JTextField();
	private final JTextField firstNameP3TF = new JTextField();
	private final JLabel lblSSNP2_1 = new JLabel("Last 4 Digits of SSN:");
	private final JFormattedTextField ssnFTFP3 = new JFormattedTextField();
	private final JLabel lblSigName = new JLabel("Name:");
	private final JLabel lblSigDate1 = new JLabel("Date:");
	private final JTextField sigNameTF = new JTextField();
	private final JTextField sigDateTF = new JTextField();
	private final JLabel lblCName1 = new JLabel("Child's First Name:");
	private final JTextField cName1TF = new JTextField();
	private final JLabel lblCGender1 = new JLabel("Gender:");
	private final JLabel lblCBirthdate1 = new JLabel("Birthdate:");
	private final JLabel lblCAge1 = new JLabel("Age:");
	private final JLabel lblCClothes1 = new JLabel("Clothing Size:");
	private final JLabel lblCShoes1 = new JLabel("Shoe Size:");
	private final JLabel lblCGame1 = new JLabel("Game Systems Owned:");
	private final JLabel lblCInterests1 = new JLabel("Child's Interests:");
	private final JSpinner spCBirthdate1 = new JSpinner();
	private final JSpinner spCAge1 = new JSpinner();
	private final JComboBox cGender1CB = new JComboBox();
	private final JComboBox cClothes1CB = new JComboBox();
	private final JComboBox cShoes1CB = new JComboBox();
	private final JList listCGames1 = new JList();
	private final JScrollPane scrollPane_1 = new JScrollPane();
	private final JList listCInterests1 = new JList();
	private final JScrollPane scrollPane_2 = new JScrollPane();
	private final JLabel lblCName2 = new JLabel("Child's First Name:");
	private final JTextField cName2TF = new JTextField();
	private final JLabel lblCGender2 = new JLabel("Gender:");
	private final JLabel lblCBirthdate2 = new JLabel("Birthdate:");
	private final JLabel lblCAge2 = new JLabel("Age:");
	private final JLabel lblCClothes2 = new JLabel("Clothing Size:");
	private final JLabel lblCShoes2 = new JLabel("Shoe Size:");
	private final JLabel lblCGame2 = new JLabel("Game Systems Owned:");
	private final JLabel lblCInterests2 = new JLabel("Child's Interests:");
	private final JSpinner spCBirthdate2 = new JSpinner();
	private final JSpinner spCAge2 = new JSpinner();
	private final JComboBox cGender2CB = new JComboBox();
	private final JComboBox cClothes2CB = new JComboBox();
	private final JComboBox cShoes2CB = new JComboBox();
	private final JList listCGames2 = new JList();
	private final JList listCInterests2 = new JList();
	private final JScrollPane scrollPane_3 = new JScrollPane();
	private final JScrollPane scrollPane_4 = new JScrollPane();
	private final JLabel lblTotalHouse_1 = new JLabel("Total Number in Household: ");
	private final JLabel lblP2Instructions_1 = new JLabel("LIST ALL OTHER HOUSEHOLD MEMBERS 14 AND OLDER\r\n");
	private final JSpinner spTotalHouse = new JSpinner();
	private final JLabel lblHName1 = new JLabel("Name:");
	private final JLabel lblHRelationship1 = new JLabel("Relationship:");
	private final JLabel lblHAge1 = new JLabel("Age:");
	private final JLabel lblHName3 = new JLabel("Name:");
	private final JLabel lblHRelationship3 = new JLabel("Relationship:");
	private final JLabel lblHAge3 = new JLabel("Age:");
	private final JLabel lblHName2 = new JLabel("Name:");
	private final JLabel lblHRelationship2 = new JLabel("Relationship:");
	private final JLabel lblHAge2 = new JLabel("Age:");
	private final JLabel lblHName4 = new JLabel("Name:");
	private final JLabel lblHRelationship4 = new JLabel("Relationship:");
	private final JLabel lblHAge4 = new JLabel("Age:");
	private final JTextField hName1TF = new JTextField();
	private final JSpinner spHAge1 = new JSpinner();
	private final JTextField hName2TF = new JTextField();
	private final JSpinner spHAge2 = new JSpinner();
	private final JTextField hName3TF = new JTextField();
	private final JSpinner spHAge3 = new JSpinner();
	private final JTextField hName4TF = new JTextField();
	private final JSpinner spHAge4 = new JSpinner();
	private final JLabel lblCName3 = new JLabel("Child's First Name:");
	private final JTextField cName3TF = new JTextField();
	private final JLabel lblCGender3 = new JLabel("Gender:");
	private final JLabel lblCBirthdate3 = new JLabel("Birthdate:");
	private final JLabel lblCAge3 = new JLabel("Age:");
	private final JLabel lblCClothes3 = new JLabel("Clothing Size:");
	private final JLabel lblCShoes3 = new JLabel("Shoe Size:");
	private final JLabel lblCGame3 = new JLabel("Game Systems Owned:");
	private final JLabel lblCInterests3 = new JLabel("Child's Interests:");
	private final JSpinner spCBirthdate3 = new JSpinner();
	private final JSpinner spCAge3 = new JSpinner();
	private final JComboBox cGender3CB = new JComboBox();
	private final JComboBox cClothes3CB = new JComboBox();
	private final JComboBox cShoes3CB = new JComboBox();
	private final JLabel lblTotalChildren = new JLabel("Total Number of Children:");
	private final JSpinner spTotalChildren = new JSpinner();
	private final JList listCGames3 = new JList();
	private final JList listCInterests3 = new JList();
	private final JScrollPane scrollPane_5 = new JScrollPane();
	private final JScrollPane scrollPane_6 = new JScrollPane();
	private final JLabel lblPage2 = new JLabel("Page 2");
	private final JLabel lblMIncome = new JLabel("MONTHLY INCOME");
	private final JLabel lblSalary = new JLabel("Salary:");
	private final JLabel lblVetAd = new JLabel("Veteran's Administration:\r\n");
	private final JLabel lblPension = new JLabel("Pension:");
	private final JLabel lblAliCh = new JLabel("Alimony/Child Support\r\n:");
	private final JLabel lblUnemploy = new JLabel("Unemployed:");
	private final JLabel lblOtherI = new JLabel("Other: ");
	
	private final JFormattedTextField otherIFTF = new JFormattedTextField(numberFormat);
	private final JFormattedTextField unemployedFTF = new JFormattedTextField(numberFormat);
	private final JFormattedTextField aliChFTF = new JFormattedTextField(numberFormat);
	private final JFormattedTextField pensionFTF = new JFormattedTextField(numberFormat);
	private final JFormattedTextField vetAdFTF = new JFormattedTextField(numberFormat);
	private final JFormattedTextField salaryFTF = new JFormattedTextField(numberFormat);
	
	private final JLabel lblSpec = new JLabel("(Specify Below)");
	private final JLabel lblTotalIncome = new JLabel("TOTAL INCOME:");
	
	private final JFormattedTextField totalIncomeFTF = new JFormattedTextField(numberFormat);
	private final JTextArea otherITA = new JTextArea();
	
	private final JLabel lblMExpenses = new JLabel("MONTHLY EXPENSES");
	private final JLabel lblHousing = new JLabel("Housing:");
	private final JLabel lblUtilities = new JLabel("Utilities:");
	private final JLabel lblInsurance = new JLabel("Insurance:");
	private final JLabel lblMedical = new JLabel("Medical:");
	private final JLabel lblFood = new JLabel("Food:");
	private final JLabel lblEOther = new JLabel("Other: ");
	
	private final JFormattedTextField otherEFTF = new JFormattedTextField(numberFormat);
	private final JFormattedTextField foodFTF = new JFormattedTextField(numberFormat);
	private final JFormattedTextField medicalFTF = new JFormattedTextField(numberFormat);
	private final JFormattedTextField insuranceFTF = new JFormattedTextField(numberFormat);
	private final JFormattedTextField utilitiesFTF = new JFormattedTextField(numberFormat);
	private final JFormattedTextField housingFTF = new JFormattedTextField(numberFormat);
	
	private final JLabel lblSpec_1 = new JLabel("(Specify Below)");
	private final JLabel lblTotalExpenses = new JLabel("TOTAL EXPENSES:");
	
	private final JFormattedTextField totalExpensesFTF = new JFormattedTextField(numberFormat);
	
	private final JTextArea otherETA = new JTextArea();
	
	private double salaryNum = 0;
	private double vetAdNum = 0;
	private double pensionNum = 0;
	private double aliChNum = 0;
	private double unemployNum = 0;
	private double otherINum = 0;
	private double totalIncomeNum = 0;
	private double housingNum = 0;
	private double utilitiesNum = 0;
	private double insuranceNum = 0;
	private double medicalNum = 0;
	private double foodNum = 0;
	private double otherENum = 0;
	private double totalExpenseNum = 0;
	private double totalNetNum = 0;
	
	private final JComboBox hRelationship1CB = new JComboBox();
	private final JComboBox hRelationship2CB = new JComboBox();
	private final JComboBox hRelationship3CB = new JComboBox();
	private final JComboBox hRelationship4CB = new JComboBox();
	private final JScrollPane scrollPane_7 = new JScrollPane();
	private final JLabel lblNewLabel_1 = new JLabel("<html>\r\nHave you applied for Chirstmas assistance with\r\n<br>\r\nany other agency, church or organization?\r\n</html>");
	private final JMenuItem mntmApplicant = new JMenuItem("Applicant Help");
	private final JMenuItem mntmFinancial = new JMenuItem("Financial Help");
	private final JMenuItem mntmShopping = new JMenuItem("Shopping Help");
	private final JSeparator separator = new JSeparator();
	private final JSeparator separator_1 = new JSeparator();
	private final JLabel lblMoneySign = new JLabel("$");
	private final JLabel lblMoneySign_1 = new JLabel("$");
	private final JLabel lblMoneySign_2 = new JLabel("$");
	private final JLabel lblMoneySign_3 = new JLabel("$");
	private final JLabel lblMoneySign_4 = new JLabel("$");
	private final JLabel lblMoneySign_5 = new JLabel("$");
	private final JLabel lblMoneySign_6 = new JLabel("$");
	private final JLabel lblMoneySign_7 = new JLabel("$");
	private final JLabel lblMoneySign_8 = new JLabel("$");
	private final JLabel lblMoneySign_9 = new JLabel("$");
	private final JLabel lblMoneySign_10 = new JLabel("$");
	private final JLabel lblMoneySign_11 = new JLabel("$");
	private final JLabel lblMoneySign_12 = new JLabel("$");
	private final JLabel lblMoneySign_13 = new JLabel("$");
	private final JLabel lblNetIncome = new JLabel("TOTAL NET INCOME:");
	private final JSeparator separator_2 = new JSeparator();
	private final JSeparator separator_2_1 = new JSeparator();
	private final JSeparator separator_2_2 = new JSeparator();
	private final JSeparator separator_2_3 = new JSeparator();
	private final JFormattedTextField totalNetFTF = new JFormattedTextField(numberFormat);
	private final JLabel lblMoneySign_2_1 = new JLabel("$");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VissicchioSACAPframe frame = new VissicchioSACAPframe();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public MaskFormatter createFormatter(String s) {
	     MaskFormatter formatter = null;
	     try {
	          formatter = new MaskFormatter(s);
	         } 
	     catch (java.text.ParseException exc) {
		          System.err.println("formatter is bad: " + exc.getMessage());
		          System.exit(-1);
		      }
	      return formatter;
	}//createFormatter

	/**
	 * Create the frame.
	 */
	public VissicchioSACAPframe() {
		cName1TF.setEnabled(false);
		cName1TF.setToolTipText("Type in your child's first name");
		cName1TF.setBounds(189, 145, 116, 22);
		cName1TF.setColumns(10);
		sigDateTF.setEditable(false);
		sigDateTF.setText("");
		sigDateTF.setBounds(725, 178, 116, 22);
		sigDateTF.setColumns(10);
		sigNameTF.setEditable(false);
		sigNameTF.setBounds(725, 149, 163, 22);
		sigNameTF.setColumns(10);
		stateTF.setToolTipText("Type in your state here");
		stateTF.setBounds(134, 335, 116, 22);
		stateTF.setColumns(10);
		cityTF.setToolTipText("Type in your city here");
		cityTF.setBounds(134, 306, 163, 22);
		cityTF.setColumns(10);
		firstNameTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				do_firstNameTF_focusGained(e);
			}
		});

		firstNameTF.setToolTipText("Type your first name here");
		firstNameTF.setBounds(223, 62, 74, 22);
		firstNameTF.setColumns(10);
		lastNameTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent arg0) {
				do_lastNameTF_focusGained(arg0);
			}
		});

		lastNameTF.setToolTipText("Type your last name here");
		lastNameTF.setBounds(134, 62, 88, 22);
		lastNameTF.setColumns(10);
		jbInit();
	}
	private void jbInit() {
		setTitle("VissicchioSACAP");
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setBounds(100, 100, 1073, 605);
		
		setJMenuBar(menuBar);
		
		menuBar.add(mnFile);
		mnStart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_mnStart_actionPerformed(arg0);
			}
		});
		
		mnFile.add(mnStart);
		mntmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_mntmExit_actionPerformed(e);
			}
		});
		
		mnFile.add(mntmExit);
		
		menuBar.add(mnHelp);
		mntmApplicant.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_mntmApplicant_actionPerformed(arg0);
			}
		});
		
		mnHelp.add(mntmApplicant);
		mntmFinancial.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_mntmFinancial_actionPerformed(arg0);
			}
		});
		
		mnHelp.add(mntmFinancial);
		mntmShopping.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				do_mntmShopping_actionPerformed(arg0);
			}
		});
		
		mnHelp.add(mntmShopping);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		tabbedPane.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				do_tabbedPane_stateChanged(e);
			}
		});
		tabbedPane.setBounds(12, 0, 1031, 519);
		
		contentPane.add(tabbedPane);


		
		tabbedPane.addTab("Applicant", null, page1, null);
		page1.setLayout(null);
		lblTitle.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblTitle.setHorizontalAlignment(SwingConstants.LEFT);
		lblTitle.setBounds(12, 0, 671, 52);
		
		page1.add(lblTitle);
		lblName.setBounds(12, 65, 128, 16);
		
		page1.add(lblName);
		lblSSN.setBounds(12, 94, 128, 16);
		
		page1.add(lblSSN);
		ssnFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				do_ssnFTF_focusGained(e);
			}
		});

		ssnFTF.setToolTipText("Type in your SSN here");
		ssnFTF.setBounds(134, 91, 88, 22);
		
		ssnMask.setPlaceholderCharacter('#');
		ssnMask.install(ssnFTF);
		
		page1.add(ssnFTF);
		lblBirthdate.setBounds(12, 123, 116, 16);
		
		page1.add(lblBirthdate);
		
		page1.add(lastNameTF);
		
		page1.add(firstNameTF);
		spinner.setToolTipText("Choose the correct date of your birth date");
		spinner.setModel(new SpinnerDateModel(new Date(1616904000000L), null, new Date(1616904000000L), Calendar.DAY_OF_YEAR));
		spinner.setBounds(134, 120, 163, 22);
		
		page1.add(spinner);
		lblMarital.setBounds(12, 152, 116, 16);
		
		page1.add(lblMarital);
		maritalCB.setToolTipText("Choose the correct marital status");
		maritalCB.setModel(new DefaultComboBoxModel(new String[] {"Married", "Separated", "Divorced", "Single"}));
		maritalCB.setMaximumRowCount(5);
		maritalCB.setBounds(134, 149, 163, 22);
		
		page1.add(maritalCB);
		lblRace.setBounds(12, 181, 116, 16);
		
		page1.add(lblRace);
		raceCB.setToolTipText("Choose the correct race using the pulldown menu");
		raceCB.setModel(new DefaultComboBoxModel(new String[] {"<html>American Inka Native </html>", "Asian", "Black or African American", "<html> Native Hawaiian or <br> Other Pacific Islander </html>", "White"}));
		raceCB.setMaximumRowCount(5);
		raceCB.setBounds(134, 178, 161, 32);
		
		page1.add(raceCB);
		lblGender.setBounds(12, 222, 56, 16);
		
		page1.add(lblGender);
		genderCB.setToolTipText("Choose the gender you best identify with");
		genderCB.setModel(new DefaultComboBoxModel(new String[] {"Male", "Female", "Non-binary", "Trr", "Prefer not to say"}));
		genderCB.setBounds(134, 219, 161, 22);
		
		page1.add(genderCB);
		lblPhoneNum.setBounds(12, 251, 116, 16);
		
		page1.add(lblPhoneNum);
		phoneFTF.setToolTipText("Type in your phone number here");
		phoneFTF.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				do_phoneFTF_focusGained(e);
			}
		});
		phoneFTF.setBounds(134, 248, 116, 22);
		
		phoneMask.setPlaceholderCharacter('#');
		phoneMask.install(phoneFTF);
		
		page1.add(phoneFTF);
		lblStreetAddress.setBounds(12, 280, 116, 16);
		
		page1.add(lblStreetAddress);
		lblCity.setBounds(12, 309, 116, 16);
		
		page1.add(lblCity);
		lblState.setBounds(12, 338, 116, 16);
		
		page1.add(lblState);
		lblZipcode.setBounds(12, 367, 116, 16);
		
		page1.add(lblZipcode);
		streetFTF.setToolTipText("Type your street address here");
		streetFTF.setBounds(134, 277, 163, 22);
		
		page1.add(streetFTF);
		
		page1.add(cityTF);
		
		page1.add(stateTF);
		zipcodeFTF.setToolTipText("Type in your zip code here");
		zipcodeFTF.setBounds(134, 364, 82, 22);
		
		zipcodeMask.setPlaceholderCharacter('#');
		zipcodeMask.install(zipcodeFTF);
		
		page1.add(zipcodeFTF);
		christmasAssistanceCB.setToolTipText("Answer the question with Yes or No");
		christmasAssistanceCB.setModel(new DefaultComboBoxModel(new String[] {"Yes", "No"}));
		christmasAssistanceCB.setMaximumRowCount(2);
		christmasAssistanceCB.setBounds(653, 72, 74, 22);
		
		page1.add(christmasAssistanceCB);
		scrollPane.setBounds(366, 107, 279, 90);
		
		page1.add(scrollPane);
		scrollPane.setViewportView(lblNewLabel);
		cbSignature.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				do_cbSignature_actionPerformed(e);
			}
		});


		cbSignature.setToolTipText("<html>\r\nClick this to confirm you understand the agreement.\r\n<br>\r\nMake sure your name is put in before selecting.\r\n</html>");
		cbSignature.setBounds(653, 119, 142, 25);
		
		page1.add(cbSignature);
		lblPage1.setBounds(958, 13, 56, 16);
		
		page1.add(lblPage1);
		lblSigName.setBounds(657, 152, 56, 16);
		
		page1.add(lblSigName);
		lblSigDate1.setBounds(657, 181, 56, 16);
		
		page1.add(lblSigDate1);
		
		page1.add(sigNameTF);
		
		page1.add(sigDateTF);
		lblTotalHouse_1.setBounds(366, 251, 169, 16);
		
		page1.add(lblTotalHouse_1);
		lblP2Instructions_1.setBounds(366, 222, 331, 16);
		
		page1.add(lblP2Instructions_1);
		spTotalHouse.setModel(new SpinnerNumberModel(0, 0, 4, 1));
		spTotalHouse.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
				do_spTotalHouse_stateChanged(arg0);
			}
		});
		spTotalHouse.setToolTipText("<html>\r\nUse the arrows to choose the \r\n<br>\r\ncorrect number in your household.\r\n</html>");
		spTotalHouse.setBounds(547, 248, 56, 22);
		
		page1.add(spTotalHouse);
		lblHName1.setEnabled(false);
		lblHName1.setBounds(366, 290, 56, 16);
		
		page1.add(lblHName1);
		lblHRelationship1.setEnabled(false);
		lblHRelationship1.setBounds(366, 319, 93, 16);
		
		page1.add(lblHRelationship1);
		lblHAge1.setEnabled(false);
		lblHAge1.setBounds(366, 348, 56, 16);
		
		page1.add(lblHAge1);
		lblHName3.setEnabled(false);
		lblHName3.setBounds(738, 290, 56, 16);
		
		page1.add(lblHName3);
		lblHRelationship3.setEnabled(false);
		lblHRelationship3.setBounds(738, 319, 81, 16);
		
		page1.add(lblHRelationship3);
		lblHAge3.setEnabled(false);
		lblHAge3.setBounds(738, 348, 56, 16);
		
		page1.add(lblHAge3);
		lblHName2.setEnabled(false);
		lblHName2.setBounds(366, 395, 56, 16);
		
		page1.add(lblHName2);
		lblHRelationship2.setEnabled(false);
		lblHRelationship2.setBounds(366, 424, 81, 16);
		
		page1.add(lblHRelationship2);
		lblHAge2.setEnabled(false);
		lblHAge2.setBounds(366, 453, 56, 16);
		
		page1.add(lblHAge2);
		lblHName4.setEnabled(false);
		lblHName4.setBounds(738, 395, 56, 16);
		
		page1.add(lblHName4);
		lblHRelationship4.setEnabled(false);
		lblHRelationship4.setBounds(738, 424, 81, 16);
		
		page1.add(lblHRelationship4);
		lblHAge4.setEnabled(false);
		lblHAge4.setBounds(738, 453, 56, 16);
		
		page1.add(lblHAge4);
		hName1TF.setToolTipText("Type in the name of the first person in your household");
		hName1TF.setEnabled(false);
		hName1TF.setColumns(10);
		hName1TF.setBounds(448, 287, 169, 22);
		
		page1.add(hName1TF);
		spHAge1.setToolTipText("<html>\r\nUse the arrows to choose the correct age of the \r\n<br>\r\nfirst person in your household\r\n</html>");
		spHAge1.setModel(new SpinnerNumberModel(new Integer(14), new Integer(14), null, new Integer(1)));
		spHAge1.setEnabled(false);
		spHAge1.setBounds(448, 345, 48, 22);
		
		page1.add(spHAge1);
		hName2TF.setToolTipText("Type in the name of the second person in your household");
		hName2TF.setEnabled(false);
		hName2TF.setColumns(10);
		hName2TF.setBounds(448, 392, 169, 22);
		
		page1.add(hName2TF);
		spHAge2.setToolTipText("<html>\r\nUse the arrows to choose the correct age of the \r\n<br>\r\nsecond person in your household\r\n</html>");
		spHAge2.setModel(new SpinnerNumberModel(new Integer(14), new Integer(14), null, new Integer(1)));
		spHAge2.setEnabled(false);
		spHAge2.setBounds(448, 450, 48, 22);
		
		page1.add(spHAge2);
		hName3TF.setToolTipText("Type in the name of the third person in your household");
		hName3TF.setEnabled(false);
		hName3TF.setColumns(10);
		hName3TF.setBounds(820, 287, 169, 22);
		
		page1.add(hName3TF);
		spHAge3.setToolTipText("<html>\r\nUse the arrows to choose the correct age of the \r\n<br>\r\nthird person in your household\r\n</html>");
		spHAge3.setModel(new SpinnerNumberModel(new Integer(14), new Integer(14), null, new Integer(1)));
		spHAge3.setEnabled(false);
		spHAge3.setBounds(820, 345, 48, 22);
		
		page1.add(spHAge3);
		hName4TF.setToolTipText("Type in the name of the fourth person in your household");
		hName4TF.setEnabled(false);
		hName4TF.setColumns(10);
		hName4TF.setBounds(820, 392, 169, 22);
		
		page1.add(hName4TF);
		spHAge4.setToolTipText("<html>\r\nUse the arrows to choose the correct age of the \r\n<br>\r\nfourth person in your household\r\n</html>");
		spHAge4.setModel(new SpinnerNumberModel(new Integer(14), new Integer(14), null, new Integer(1)));
		spHAge4.setEnabled(false);
		spHAge4.setBounds(820, 450, 48, 22);
		
		page1.add(spHAge4);
		hRelationship1CB.setToolTipText("<html>\r\nType in the relationship you have with \r\n<br>\r\nthe first person in the household\r\n</html>");
		hRelationship1CB.setEnabled(false);
		hRelationship1CB.setMaximumRowCount(7);
		hRelationship1CB.setModel(new DefaultComboBoxModel(new String[] {"Child", "GrandChild", "Sibling", "Parent", "GrandPaFamily", "Other"}));
		hRelationship1CB.setBounds(448, 316, 128, 22);
		
		page1.add(hRelationship1CB);
		hRelationship2CB.setToolTipText("<html>\r\nType in the relationship you have with \r\n<br>\r\nthe second person in the household\r\n</html>");
		hRelationship2CB.setEnabled(false);
		hRelationship2CB.setModel(new DefaultComboBoxModel(new String[] {"Child", "GrandChild", "Sibling", "Parent", "GrandParent", "Extended Family", "Other"}));
		hRelationship2CB.setMaximumRowCount(7);
		hRelationship2CB.setBounds(448, 421, 128, 22);
		
		page1.add(hRelationship2CB);
		hRelationship3CB.setToolTipText("<html>\r\nType in the relationship you have with \r\n<br>\r\nthe third person in the household\r\n</html>");
		hRelationship3CB.setModel(new DefaultComboBoxModel(new String[] {"Child", "GrandChild", "Sibling", "Parent", "GrandParent", "Extended Family", "Other"}));
		hRelationship3CB.setEnabled(false);
		hRelationship3CB.setMaximumRowCount(7);
		hRelationship3CB.setBounds(820, 316, 128, 22);
		
		page1.add(hRelationship3CB);
		hRelationship4CB.setToolTipText("<html>\r\nType in the relationship you have with \r\n<br>\r\nthe fourth person in the household\r\n</html>");
		hRelationship4CB.setModel(new DefaultComboBoxModel(new String[] {"Child", "GrandChild", "Sibling", "Parent", "GrandParent", "Extended Family", "Other"}));
		hRelationship4CB.setEnabled(false);
		hRelationship4CB.setMaximumRowCount(7);
		hRelationship4CB.setBounds(820, 421, 128, 22);
		
		page1.add(hRelationship4CB);
		lblNewLabel_1.setToolTipText("");
		lblNewLabel_1.setBounds(366, 62, 279, 32);
		
		page1.add(lblNewLabel_1);
		separator.setOrientation(SwingConstants.VERTICAL);
		separator.setBounds(329, 65, 2, 411);
		
		page1.add(separator);
		separator_1.setBounds(329, 210, 662, 10);
		
		page1.add(separator_1);
		page2.setToolTipText("<html>\r\nThis page takes care of financial information.\r\n<br>\r\n(Make sure the Applicant page is complete first)\r\n</html>");
		
		tabbedPane.addTab("Financial", null, page2, null);
		page2.setLayout(null);
		lblNameP3.setBounds(29, 13, 116, 16);
		
		page2.add(lblNameP3);
		lastNameP3TF.setEditable(false);
		lastNameP3TF.setToolTipText("");
		lastNameP3TF.setColumns(10);
		lastNameP3TF.setBounds(157, 10, 88, 22);
		
		page2.add(lastNameP3TF);
		firstNameP3TF.setEditable(false);
		firstNameP3TF.setToolTipText("");
		firstNameP3TF.setColumns(10);
		firstNameP3TF.setBounds(246, 10, 74, 22);
		
		page2.add(firstNameP3TF);
		lblSSNP2_1.setBounds(29, 42, 118, 16);
		
		page2.add(lblSSNP2_1);
		ssnFTFP3.setEditable(false);
		ssnFTFP3.setToolTipText("");
		ssnFTFP3.setBounds(157, 39, 88, 22);
		
		page2.add(ssnFTFP3);
		lblPage2.setBounds(958, 13, 56, 16);
		
		page2.add(lblPage2);
		lblMIncome.setHorizontalAlignment(SwingConstants.CENTER);
		lblMIncome.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblMIncome.setBounds(157, 84, 273, 16);
		
		page2.add(lblMIncome);
		lblSalary.setBounds(157, 113, 56, 16);
		
		page2.add(lblSalary);
		lblVetAd.setBounds(157, 142, 163, 16);
		
		page2.add(lblVetAd);
		lblPension.setBounds(157, 171, 56, 16);
		
		page2.add(lblPension);
		lblAliCh.setBounds(157, 200, 163, 16);
		
		page2.add(lblAliCh);
		lblUnemploy.setBounds(157, 229, 88, 16);
		
		page2.add(lblUnemploy);
		lblOtherI.setBounds(157, 258, 98, 16);
		
		page2.add(lblOtherI);
		otherIFTF.setToolTipText("Place the total obtained from other forms of monthly income");
		
		otherIFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		otherIFTF.setBounds(332, 255, 98, 22);
		
		otherIFTF.setValue(otherINum);
		
		page2.add(otherIFTF);
		unemployedFTF.setToolTipText("Place unemployed monthly income");
		
		unemployedFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		unemployedFTF.setBounds(332, 226, 98, 22);
		
		unemployedFTF.setValue(unemployNum);
		
		page2.add(unemployedFTF);
		aliChFTF.setToolTipText("Place Alimon or Child Support monthly income");

		aliChFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		aliChFTF.setBounds(332, 197, 98, 22);
		
		aliChFTF.setValue(aliChNum);
		
		page2.add(aliChFTF);
		pensionFTF.setToolTipText("Place Veteran's Administration monthly income");
		
		pensionFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		pensionFTF.setBounds(332, 168, 98, 22);
		
		pensionFTF.setValue(pensionNum);
		
		page2.add(pensionFTF);
		vetAdFTF.setToolTipText("Place Veteran's Administration monthly income");


		vetAdFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		vetAdFTF.setBounds(332, 139, 98, 22);
		
		vetAdFTF.setValue(vetAdNum);
		
		page2.add(vetAdFTF);
		salaryFTF.setToolTipText("Place salary monthly income");

		salaryFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		salaryFTF.setBounds(332, 110, 98, 22);
		
		salaryFTF.setValue(salaryNum);
		
		page2.add(salaryFTF);
		lblSpec.setBounds(157, 275, 98, 16);
		
		page2.add(lblSpec);
		lblTotalIncome.setBounds(157, 383, 98, 16);
		
		page2.add(lblTotalIncome);
		
		totalIncomeFTF.setToolTipText("<html>\r\nThe total amount of monthly income\r\n<br>\r\n(Will automatically be updated)\r\n</html>");
		totalIncomeFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		totalIncomeFTF.setBounds(332, 380, 98, 22);
		
		totalIncomeFTF.setValue(totalIncomeNum);
		
		page2.add(totalIncomeFTF);
		scrollPane_7.setBounds(157, 294, 130, 76);
		
		page2.add(scrollPane_7);
		scrollPane_7.setViewportView(otherITA);
		otherITA.setToolTipText("Specify other forms of Monthly Income");
		lblMExpenses.setHorizontalAlignment(SwingConstants.CENTER);
		lblMExpenses.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblMExpenses.setBounds(579, 84, 273, 16);
		
		page2.add(lblMExpenses);
		lblHousing.setBounds(579, 113, 74, 16);
		
		page2.add(lblHousing);
		lblUtilities.setBounds(579, 142, 163, 16);
		
		page2.add(lblUtilities);
		lblInsurance.setBounds(579, 171, 74, 16);
		
		page2.add(lblInsurance);
		lblMedical.setBounds(579, 200, 163, 16);
		
		page2.add(lblMedical);
		lblFood.setBounds(579, 229, 88, 16);
		
		page2.add(lblFood);
		lblEOther.setBounds(579, 258, 98, 16);
		
		page2.add(lblEOther);
		otherEFTF.setToolTipText("Place the total from other forms of monthly income ");
		
		otherEFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		otherEFTF.setBounds(754, 255, 98, 22);
		
		otherEFTF.setValue(otherENum);
		
		page2.add(otherEFTF);
		foodFTF.setToolTipText("Place food expenses");
		
		foodFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		foodFTF.setBounds(754, 226, 98, 22);
		
		foodFTF.setValue(foodNum);
		
		page2.add(foodFTF);
		medicalFTF.setToolTipText("Place medical expenses\r\n");
		
		medicalFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		medicalFTF.setBounds(754, 197, 98, 22);
		
		medicalFTF.setValue(medicalNum);
		
		page2.add(medicalFTF);
		insuranceFTF.setToolTipText("Place insurance expenses");
		
		insuranceFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		insuranceFTF.setBounds(754, 168, 98, 22);
		
		insuranceFTF.setValue(insuranceNum);
		
		page2.add(insuranceFTF);
		utilitiesFTF.setToolTipText("Place utilities expense\r\n");
		
		utilitiesFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		utilitiesFTF.setBounds(754, 139, 98, 22);
		
		utilitiesFTF.setValue(utilitiesNum);
		
		page2.add(utilitiesFTF);
		housingFTF.setToolTipText("Place housing expenses");
		
		housingFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		housingFTF.setBounds(754, 110, 98, 22);
		
		housingFTF.setValue(housingNum);
		
		page2.add(housingFTF);
		lblSpec_1.setBounds(579, 275, 98, 16);
		
		page2.add(lblSpec_1);
		lblTotalExpenses.setBounds(579, 383, 116, 16);
		
		page2.add(lblTotalExpenses);
		
		totalExpensesFTF.setToolTipText("<html>\r\nThe total amount of monthly expenses\r\n<br>\r\n(Will automatically be updated)\r\n</html>");
		totalExpensesFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		totalExpensesFTF.setBounds(754, 380, 98, 22);
		
		totalExpensesFTF.setValue(totalExpenseNum);
		
		page2.add(totalExpensesFTF);
		otherETA.setToolTipText("Specify other forms of monthly expenses");
		otherETA.setBounds(579, 294, 130, 76);
		
		page2.add(otherETA);
		lblMoneySign.setBounds(322, 113, 13, 16);
		
		page2.add(lblMoneySign);
		lblMoneySign_1.setBounds(322, 142, 13, 16);
		
		page2.add(lblMoneySign_1);
		lblMoneySign_2.setBounds(322, 171, 13, 16);
		
		page2.add(lblMoneySign_2);
		lblMoneySign_3.setBounds(322, 200, 13, 16);
		
		page2.add(lblMoneySign_3);
		lblMoneySign_4.setBounds(322, 229, 13, 16);
		
		page2.add(lblMoneySign_4);
		lblMoneySign_5.setBounds(322, 258, 13, 16);
		
		page2.add(lblMoneySign_5);
		lblMoneySign_6.setBounds(322, 383, 13, 16);
		
		page2.add(lblMoneySign_6);
		lblMoneySign_7.setBounds(745, 113, 13, 16);
		
		page2.add(lblMoneySign_7);
		lblMoneySign_8.setBounds(745, 142, 13, 16);
		
		page2.add(lblMoneySign_8);
		lblMoneySign_9.setBounds(745, 171, 13, 16);
		
		page2.add(lblMoneySign_9);
		lblMoneySign_10.setBounds(745, 200, 13, 16);
		
		page2.add(lblMoneySign_10);
		lblMoneySign_11.setBounds(745, 229, 13, 16);
		
		page2.add(lblMoneySign_11);
		lblMoneySign_12.setBounds(745, 258, 13, 16);
		
		page2.add(lblMoneySign_12);
		lblMoneySign_13.setBounds(745, 383, 13, 16);
		
		page2.add(lblMoneySign_13);
		lblNetIncome.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNetIncome.setBounds(335, 441, 163, 20);
		
		page2.add(lblNetIncome);
		separator_2_2.setOrientation(SwingConstants.VERTICAL);
		separator_2_2.setBounds(502, 84, 8, 328);
		
		page2.add(separator_2_2);
		separator_2_3.setBounds(29, 412, 963, 16);
		
		page2.add(separator_2_3);
		totalNetFTF.setToolTipText("<html>\r\nThe total amount of monthly income\r\n<br>\r\n(Will automatically be updated)\r\n</html>");
		totalNetFTF.setHorizontalAlignment(SwingConstants.RIGHT);
		totalNetFTF.setBounds(520, 439, 98, 22);
		
		totalNetFTF.setValue(totalNetNum);
		
		page2.add(totalNetFTF);
		lblMoneySign_2_1.setBounds(510, 442, 13, 16);
		
		page2.add(lblMoneySign_2_1);
		
		salaryFTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				do_salaryFTF_propertyChange(evt);
			}
		});
		
		vetAdFTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				do_vetAdFTF_propertyChange(evt);
			}
		});
		
		pensionFTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				do_pensionFTF_propertyChange(evt);
			}
		});
		
		aliChFTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				do_aliChFTF_propertyChange(evt);
			}
		});
		
		unemployedFTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				do_unemployedFTF_propertyChange(evt);
			}
		});
		
		otherIFTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				do_otherIFTF_propertyChange(evt);
			}
		});
		
		housingFTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				do_housingFTF_propertyChange(evt);
			}
		});
		utilitiesFTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				do_utilitiesFTF_propertyChange(evt);
			}
		});
		
		insuranceFTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				do_insuranceFTF_propertyChange(evt);
			}
		});
		
		medicalFTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				do_medicalFTF_propertyChange(evt);
			}
		});
		
		foodFTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				do_foodFTF_propertyChange(evt);
			}
		});
		
		otherEFTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				do_otherEFTF_propertyChange(evt);
			}
		});
		totalIncomeFTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent arg0) {
				do_totalIncomeFTF_propertyChange(arg0);
			}
		});
		totalExpensesFTF.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				do_totalExpensesFTF_propertyChange(evt);
			}
		});
		
		
		tabbedPane.addTab("Shopping", null, page3, null);
		page3.setLayout(null);
		lblNameP4.setBounds(29, 13, 116, 16);
		
		page3.add(lblNameP4);
		lastNameP4TF.setEditable(false);
		lastNameP4TF.setToolTipText("");
		lastNameP4TF.setColumns(10);
		lastNameP4TF.setBounds(157, 10, 88, 22);
		
		page3.add(lastNameP4TF);
		firstNameP4TF.setEditable(false);
		firstNameP4TF.setToolTipText("");
		firstNameP4TF.setColumns(10);
		firstNameP4TF.setBounds(246, 10, 74, 22);
		
		page3.add(firstNameP4TF);
		lblSSNP4.setBounds(29, 42, 118, 16);
		
		page3.add(lblSSNP4);
		ssnFTFP4.setEditable(false);
		ssnFTFP4.setToolTipText("");
		ssnFTFP4.setBounds(157, 39, 88, 22);
		
		page3.add(ssnFTFP4);
		lblPage3.setBounds(958, 13, 56, 16);
		
		page3.add(lblPage3);
		lblAppChildren.setBounds(29, 71, 729, 16);
		
		page3.add(lblAppChildren);
		lblCName1.setEnabled(false);
		lblCName1.setBounds(29, 148, 116, 16);
		
		page3.add(lblCName1);
		
		page3.add(cName1TF);
		lblCGender1.setEnabled(false);
		lblCGender1.setBounds(29, 180, 56, 16);
		
		page3.add(lblCGender1);
		lblCBirthdate1.setEnabled(false);
		lblCBirthdate1.setBounds(29, 209, 56, 16);
		
		page3.add(lblCBirthdate1);
		lblCAge1.setEnabled(false);
		lblCAge1.setBounds(29, 238, 56, 16);
		
		page3.add(lblCAge1);
		lblCClothes1.setEnabled(false);
		lblCClothes1.setBounds(29, 267, 116, 16);
		
		page3.add(lblCClothes1);
		lblCShoes1.setEnabled(false);
		lblCShoes1.setBounds(29, 296, 116, 16);
		
		page3.add(lblCShoes1);
		lblCGame1.setEnabled(false);
		lblCGame1.setBounds(29, 325, 142, 16);
		
		page3.add(lblCGame1);
		lblCInterests1.setEnabled(false);
		lblCInterests1.setBounds(29, 402, 116, 16);
		
		page3.add(lblCInterests1);
		spCBirthdate1.setEnabled(false);
		spCBirthdate1.setModel(new SpinnerDateModel(new Date(1617422400000L), null, new Date(1617422400000L), Calendar.DAY_OF_YEAR));
		spCBirthdate1.setToolTipText("Choose the correct date of your child's birth date");
		spCBirthdate1.setBounds(189, 206, 129, 22);
		
		page3.add(spCBirthdate1);
		spCAge1.setToolTipText("Use the arrows to choose your child's age");
		spCAge1.setEnabled(false);
		spCAge1.setModel(new SpinnerNumberModel(0, 0, 13, 1));
		spCAge1.setBounds(189, 235, 48, 22);
		
		page3.add(spCAge1);
		cGender1CB.setToolTipText("Choose the child's gender");
		cGender1CB.setEnabled(false);
		cGender1CB.setMaximumRowCount(2);
		cGender1CB.setModel(new DefaultComboBoxModel(new String[] {"M", "F"}));
		cGender1CB.setBounds(189, 177, 48, 22);
		
		page3.add(cGender1CB);
		cClothes1CB.setToolTipText("Select your child's clothing size");
		cClothes1CB.setEnabled(false);
		cClothes1CB.setModel(new DefaultComboBoxModel(new String[] {"XS", "S", "M", "L", "XL", "2X"}));
		cClothes1CB.setMaximumRowCount(6);
		cClothes1CB.setBounds(189, 264, 48, 22);
		
		page3.add(cClothes1CB);
		cShoes1CB.setToolTipText("Choose your child's shoe size");
		cShoes1CB.setEnabled(false);
		cShoes1CB.setModel(new DefaultComboBoxModel(new String[] {"4", "4.5", "5", "5.5", "6", "6.5", "7", "7.5", "8", "8.5", "9", "9.5", "10", "10.5", "11", "11.5", "12", "13", "14", "15"}));
		cShoes1CB.setMaximumRowCount(20);
		cShoes1CB.setBounds(189, 293, 48, 22);
		
		page3.add(cShoes1CB);
		scrollPane_1.setBounds(191, 323, 129, 63);
		
		page3.add(scrollPane_1);
		listCGames1.setToolTipText("<html>\r\nChoose all Game Systems that you\r\n<br>\r\ncurrently own\r\n</html>");
		listCGames1.setEnabled(false);
		scrollPane_1.setViewportView(listCGames1);
		listCGames1.setModel(new AbstractListModel() {
			String[] values = new String[] {"Xbox 360", "Xbox One", "PS3", "PS4", "PSP", "Wii", "Wii U", "Nintendo DS", "PC"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		scrollPane_2.setBounds(191, 400, 129, 63);
		
		page3.add(scrollPane_2);
		listCInterests1.setToolTipText("Choose all of your child's interests");
		listCInterests1.setEnabled(false);
		scrollPane_2.setViewportView(listCInterests1);
		listCInterests1.setModel(new AbstractListModel() {
			String[] values = new String[] {"Arts/Crafts", "Drawing", "Action Heroes", "Cars/Trucks", "Planes/Trains", "Music", "Construction", "Lego/Duplo", "Outdoors", "Dolls", "Sports", "Other"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		lblCName2.setEnabled(false);
		lblCName2.setBounds(363, 149, 116, 16);
		
		page3.add(lblCName2);
		cName2TF.setEnabled(false);
		cName2TF.setToolTipText("Type in your child's first name");
		cName2TF.setColumns(10);
		cName2TF.setBounds(523, 146, 116, 22);
		
		page3.add(cName2TF);
		lblCGender2.setEnabled(false);
		lblCGender2.setBounds(363, 181, 56, 16);
		
		page3.add(lblCGender2);
		lblCBirthdate2.setEnabled(false);
		lblCBirthdate2.setBounds(363, 210, 56, 16);
		
		page3.add(lblCBirthdate2);
		lblCAge2.setEnabled(false);
		lblCAge2.setBounds(363, 239, 56, 16);
		
		page3.add(lblCAge2);
		lblCClothes2.setEnabled(false);
		lblCClothes2.setBounds(363, 268, 116, 16);
		
		page3.add(lblCClothes2);
		lblCShoes2.setEnabled(false);
		lblCShoes2.setBounds(363, 297, 116, 16);
		
		page3.add(lblCShoes2);
		lblCGame2.setEnabled(false);
		lblCGame2.setBounds(363, 326, 142, 16);
		
		page3.add(lblCGame2);
		lblCInterests2.setEnabled(false);
		lblCInterests2.setBounds(363, 402, 116, 16);
		
		page3.add(lblCInterests2);
		spCBirthdate2.setEnabled(false);
		spCBirthdate2.setModel(new SpinnerDateModel(new Date(1617422400000L), null, new Date(1617422400000L), Calendar.DAY_OF_YEAR));
		spCBirthdate2.setToolTipText("Choose the correct date of your child's birth date");
		spCBirthdate2.setBounds(523, 206, 129, 22);
		
		page3.add(spCBirthdate2);
		spCAge2.setToolTipText("Use the arrows to choose your child's age");
		spCAge2.setEnabled(false);
		spCAge2.setModel(new SpinnerNumberModel(0, 0, 13, 1));
		spCAge2.setBounds(523, 235, 48, 22);
		
		page3.add(spCAge2);
		cGender2CB.setToolTipText("Choose the child's gender");
		cGender2CB.setEnabled(false);
		cGender2CB.setModel(new DefaultComboBoxModel(new String[] {"M", "F"}));
		cGender2CB.setMaximumRowCount(2);
		cGender2CB.setBounds(523, 177, 48, 22);
		
		page3.add(cGender2CB);
		cClothes2CB.setToolTipText("Select your child's clothing size");
		cClothes2CB.setEnabled(false);
		cClothes2CB.setModel(new DefaultComboBoxModel(new String[] {"XS", "S", "M", "L", "XL", "2X"}));
		cClothes2CB.setMaximumRowCount(6);
		cClothes2CB.setBounds(523, 264, 48, 22);
		
		page3.add(cClothes2CB);
		cShoes2CB.setToolTipText("Choose your child's shoe size");
		cShoes2CB.setEnabled(false);
		cShoes2CB.setModel(new DefaultComboBoxModel(new String[] {"4", "4.5", "5", "5.5", "6", "6.5", "7", "7.5", "8", "8.5", "9", "9.5", "10", "10.5", "11", "11.5", "12", "13", "14", "15"}));
		cShoes2CB.setMaximumRowCount(20);
		cShoes2CB.setBounds(523, 293, 48, 22);
		
		page3.add(cShoes2CB);
		scrollPane_3.setBounds(523, 323, 116, 63);
		
		page3.add(scrollPane_3);
		listCGames2.setToolTipText("<html>\r\nChoose all Game Systems that you\r\n<br>\r\ncurrently own\r\n</html>");
		listCGames2.setEnabled(false);
		listCGames2.setModel(new AbstractListModel() {
			String[] values = new String[] {"Xbox 360", "Xbox One", "PS3", "PS4", "PSP", "Wii", "Wii U", "Nintendo DS", "PC"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		scrollPane_3.setViewportView(listCGames2);
		scrollPane_4.setBounds(523, 400, 116, 63);
		
		page3.add(scrollPane_4);
		listCInterests2.setToolTipText("Choose all of your child's interests");
		listCInterests2.setEnabled(false);
		scrollPane_4.setViewportView(listCInterests2);
		listCInterests2.setModel(new AbstractListModel() {
			String[] values = new String[] {"Arts/Crafts", "Drawing", "Action Heroes", "Cars/Trucks", "Planes/Trains", "Music", "Construction", "Lego/Duplo", "Outdoors", "Dolls", "Sports", "Other"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		lblCName3.setEnabled(false);
		lblCName3.setBounds(694, 149, 116, 16);
		
		page3.add(lblCName3);
		cName3TF.setEnabled(false);
		cName3TF.setToolTipText("Type in your child's first name");
		cName3TF.setColumns(10);
		cName3TF.setBounds(854, 146, 116, 22);
		
		page3.add(cName3TF);
		lblCGender3.setEnabled(false);
		lblCGender3.setBounds(694, 181, 56, 16);
		
		page3.add(lblCGender3);
		lblCBirthdate3.setEnabled(false);
		lblCBirthdate3.setBounds(694, 210, 56, 16);
		
		page3.add(lblCBirthdate3);
		lblCAge3.setEnabled(false);
		lblCAge3.setBounds(694, 239, 56, 16);
		
		page3.add(lblCAge3);
		lblCClothes3.setEnabled(false);
		lblCClothes3.setBounds(694, 268, 116, 16);
		
		page3.add(lblCClothes3);
		lblCShoes3.setEnabled(false);
		lblCShoes3.setBounds(694, 297, 116, 16);
		
		page3.add(lblCShoes3);
		lblCGame3.setEnabled(false);
		lblCGame3.setBounds(694, 326, 142, 16);
		
		page3.add(lblCGame3);
		lblCInterests3.setEnabled(false);
		lblCInterests3.setBounds(694, 402, 116, 16);
		
		page3.add(lblCInterests3);
		spCBirthdate3.setModel(new SpinnerDateModel(new Date(1617422400000L), null, new Date(1617422400000L), Calendar.DAY_OF_YEAR));
		spCBirthdate3.setEnabled(false);
		spCBirthdate3.setToolTipText("Choose the correct date of your child's birth date");
		spCBirthdate3.setBounds(854, 206, 129, 22);
		
		page3.add(spCBirthdate3);
		spCAge3.setToolTipText("Use the arrows to choose your child's age");
		spCAge3.setModel(new SpinnerNumberModel(0, 0, 13, 1));
		spCAge3.setEnabled(false);
		spCAge3.setBounds(854, 235, 48, 22);
		
		page3.add(spCAge3);
		cGender3CB.setToolTipText("Choose the child's gender");
		cGender3CB.setModel(new DefaultComboBoxModel(new String[] {"M", "F"}));
		cGender3CB.setEnabled(false);
		cGender3CB.setMaximumRowCount(2);
		cGender3CB.setBounds(854, 177, 48, 22);
		
		page3.add(cGender3CB);
		cClothes3CB.setModel(new DefaultComboBoxModel(new String[] {"XS", "S", "M", "L", "XL", "2X"}));
		cClothes3CB.setToolTipText("Select your child's clothing size");
		cClothes3CB.setEnabled(false);
		cClothes3CB.setMaximumRowCount(6);
		cClothes3CB.setBounds(854, 264, 48, 22);
		
		page3.add(cClothes3CB);
		cShoes3CB.setToolTipText("Choose your child's shoe size");
		cShoes3CB.setModel(new DefaultComboBoxModel(new String[] {"4", "4.5", "5", "5.5", "6", "6.5", "7", "7.5", "8", "8.5", "9", "9.5", "10", "10.5", "11", "11.5", "12", "13", "14", "15"}));
		cShoes3CB.setEnabled(false);
		cShoes3CB.setMaximumRowCount(20);
		cShoes3CB.setBounds(854, 293, 48, 22);
		
		page3.add(cShoes3CB);
		lblTotalChildren.setBounds(29, 104, 166, 16);
		
		page3.add(lblTotalChildren);
		spTotalChildren.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
				do_spTotalChildren_stateChanged(arg0);
			}
		});
		spTotalChildren.setModel(new SpinnerNumberModel(0, 0, 3, 1));
		spTotalChildren.setToolTipText("Use the arrows to choose the correct number in your household.");
		spTotalChildren.setBounds(189, 100, 56, 22);
		
		page3.add(spTotalChildren);
		scrollPane_5.setBounds(850, 324, 120, 63);
		
		page3.add(scrollPane_5);
		listCGames3.setToolTipText("<html>\r\nChoose all Game Systems that you\r\n<br>\r\ncurrently own\r\n</html>");
		scrollPane_5.setViewportView(listCGames3);
		listCGames3.setModel(new AbstractListModel() {
			String[] values = new String[] {"Xbox 360", "Xbox One", "PS3", "PS4", "PSP", "Wii", "Wii U", "Nintendo DS", "PC"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		listCGames3.setEnabled(false);
		scrollPane_6.setBounds(850, 401, 120, 63);
		
		page3.add(scrollPane_6);
		listCInterests3.setToolTipText("Choose all of your child's interests");
		scrollPane_6.setViewportView(listCInterests3);
		listCInterests3.setModel(new AbstractListModel() {
			String[] values = new String[] {"Arts/Crafts", "Drawing", "Action Heroes", "Cars/Trucks", "Planes/Trains", "Music", "Construction", "Lego/Duplo", "Outdoors", "Dolls", "Sports", "Other"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		listCInterests3.setEnabled(false);
		separator_2.setOrientation(SwingConstants.VERTICAL);
		separator_2.setBounds(343, 148, 8, 328);
		
		page3.add(separator_2);
		separator_2_1.setOrientation(SwingConstants.VERTICAL);
		separator_2_1.setBounds(674, 148, 8, 328);
		
		page3.add(separator_2_1);
	}
	
	protected void do_tabbedPane_stateChanged(ChangeEvent e) {
		lastNameP3TF.setText(lastNameTF.getText());
		lastNameP4TF.setText(lastNameTF.getText());
		firstNameP3TF.setText(firstNameTF.getText());
		firstNameP4TF.setText(firstNameTF.getText());
		ssnFTFP3.setText(ssnFTF.getText());
		ssnFTFP4.setText(ssnFTF.getText());
		
		if (tabbedPane.getSelectedIndex() == 1 || tabbedPane.getSelectedIndex() == 2)
		{
			if (lastNameTF.getText().trim().isEmpty() || firstNameTF.getText().trim().isEmpty() || ssnFTF.getText().contains("#")
					|| cbSignature.isSelected() == false)
			{
				tabbedPane.setSelectedIndex(0);
				if (cbSignature.isSelected() == false)
				{
					cbSignature.setForeground(Color.RED);
					cbSignature.requestFocusInWindow();
				}//else if
				else
				{
					cbSignature.setForeground(Color.BLACK);
				}//else
				if (ssnFTF.getText().contains("#"))
				{
					lblSSN.setForeground(Color.RED);
					ssnFTF.requestFocusInWindow();
				}//if
				else
				{
					lblSSN.setForeground(Color.BLACK);
				}//else
				if (lastNameTF.getText().trim().isEmpty() || firstNameTF.getText().trim().isEmpty())
				{
					lblName.setForeground(Color.RED);
					lastNameTF.requestFocusInWindow();
				}//if
				else
				{
					lblName.setForeground(Color.BLACK);
				}//else
				JOptionPane.showMessageDialog(this, "Make sure you fill out required fields!", "Empty Text Error", JOptionPane.ERROR_MESSAGE);
			}//if
			if (tabbedPane.getSelectedIndex() == 2)
			{
				if ((Double) totalIncomeFTF.getValue() == 0 || (Double) totalExpensesFTF.getValue() == 0)
				{
					tabbedPane.setSelectedIndex(1);
					if ((Double) totalIncomeFTF.getValue() == 0)
					{
						lblTotalIncome.setForeground(Color.RED);
						totalIncomeFTF.requestFocusInWindow();
					}//if
					else
					{
						lblTotalIncome.setForeground(Color.BLACK);
					}//else
					if ((Double) totalExpensesFTF.getValue() == 0)
					{
						lblTotalExpenses.setForeground(Color.RED);
						totalExpensesFTF.requestFocusInWindow();
					}//if
					else
					{
						lblTotalExpenses.setForeground(Color.BLACK);
					}//else
					JOptionPane.showMessageDialog(this, "Make sure you have filled in financials"
							+ "\n accurately before proceeding.", "Empty Text Error", JOptionPane.ERROR_MESSAGE);
				}//if
			}//if
			
		}//if
	}
	protected void do_lastNameTF_focusGained(FocusEvent arg0) {
		lastNameTF.selectAll();
	}
	protected void do_firstNameTF_focusGained(FocusEvent e) {
		firstNameTF.selectAll();
	}
	protected void do_ssnFTF_focusGained(FocusEvent e) {
		ssnFTF.select(0, 0);
	}
	protected void do_phoneFTF_focusGained(FocusEvent e) {
		phoneFTF.select(1, 1);
	}


	protected void do_cbSignature_actionPerformed(ActionEvent e) {
		DateTimeFormatter date = DateTimeFormatter.ofPattern("MM/dd/yyyy");
		LocalDateTime now = LocalDateTime.now();
		if (cbSignature.isSelected())
		{
			sigNameTF.setText(firstNameTF.getText().trim() + " " + lastNameTF.getText().trim());
			sigDateTF.setText(date.format(now));
		}//if
		else
		{
			sigNameTF.setText("");
			sigDateTF.setText("");
		}//else
	}
	protected void do_spTotalHouse_stateChanged(ChangeEvent arg0) {
		int houseVal = (Integer) spTotalHouse.getValue(); 
		if (houseVal >= 1)
		{
			lblHName1.setEnabled(true);
			hName1TF.setEnabled(true);
			lblHRelationship1.setEnabled(true);
			hRelationship1CB.setEnabled(true);
			lblHAge1.setEnabled(true);
			spHAge1.setEnabled(true);
		}//if
		else
		{
			lblHName1.setEnabled(false);
			hName1TF.setEnabled(false);
			lblHRelationship1.setEnabled(false);
			hRelationship1CB.setEnabled(false);
			lblHAge1.setEnabled(false);
			spHAge1.setEnabled(false);
		}//else
		if (houseVal >= 2)
		{
			lblHName2.setEnabled(true);
			hName2TF.setEnabled(true);
			lblHRelationship2.setEnabled(true);
			hRelationship2CB.setEnabled(true);
			lblHAge2.setEnabled(true);
			spHAge2.setEnabled(true);
		}//if
		else
		{
			lblHName2.setEnabled(false);
			hName2TF.setEnabled(false);
			lblHRelationship2.setEnabled(false);
			hRelationship2CB.setEnabled(false);
			lblHAge2.setEnabled(false);
			spHAge2.setEnabled(false);
		}//else
		if (houseVal >= 3)
		{
			lblHName3.setEnabled(true);
			hName3TF.setEnabled(true);
			lblHRelationship3.setEnabled(true);
			hRelationship3CB.setEnabled(true);
			lblHAge3.setEnabled(true);
			spHAge3.setEnabled(true);
		}//if
		else
		{
			lblHName3.setEnabled(false);
			hName3TF.setEnabled(false);
			lblHRelationship3.setEnabled(false);
			hRelationship3CB.setEnabled(false);
			lblHAge3.setEnabled(false);
			spHAge3.setEnabled(false);
		}//else
		if (houseVal >= 4)
		{
			lblHName4.setEnabled(true);
			hName4TF.setEnabled(true);
			lblHRelationship4.setEnabled(true);
			hRelationship4CB.setEnabled(true);
			lblHAge4.setEnabled(true);
			spHAge4.setEnabled(true);
		}//if
		else
		{
			lblHName4.setEnabled(false);
			hName4TF.setEnabled(false);
			lblHRelationship4.setEnabled(false);
			hRelationship4CB.setEnabled(false);
			lblHAge4.setEnabled(false);
			spHAge4.setEnabled(false);
		}//else
	}
	
	private void doSum()
	{
		double sum1;
		salaryNum = ((Number)salaryFTF.getValue()).doubleValue();
		vetAdNum = ((Number)vetAdFTF.getValue()).doubleValue();
		pensionNum = ((Number)pensionFTF.getValue()).doubleValue();
		aliChNum = ((Number)aliChFTF.getValue()).doubleValue();
		unemployNum = ((Number)unemployedFTF.getValue()).doubleValue();
		otherINum = ((Number)otherIFTF.getValue()).doubleValue();
		sum1 = salaryNum + vetAdNum + pensionNum + aliChNum + unemployNum + otherINum;
		totalIncomeFTF.setValue(sum1);
		totalIncomeNum = sum1;
		if (totalIncomeNum < 0)
		{
			totalIncomeFTF.setForeground(Color.RED);
		}//if
		else
		{
			totalIncomeFTF.setForeground(Color.BLACK);
		}//else
		
		double sum2;
		housingNum = ((Number)housingFTF.getValue()).doubleValue();
		utilitiesNum = ((Number)utilitiesFTF.getValue()).doubleValue();
		insuranceNum = ((Number)insuranceFTF.getValue()).doubleValue();
		medicalNum = ((Number)medicalFTF.getValue()).doubleValue();
		foodNum = ((Number)foodFTF.getValue()).doubleValue();
		otherENum = ((Number)otherEFTF.getValue()).doubleValue();
		sum2 = housingNum + utilitiesNum + insuranceNum + medicalNum + foodNum + otherENum;
		totalExpensesFTF.setValue(sum2);
		totalExpenseNum = sum2;
		totalExpensesFTF.setForeground(Color.RED);
		
		double sum3;
		sum3 = sum1 + -(sum2);
		totalNetNum = sum3;
		totalNetFTF.setValue(sum3);
		if (totalNetNum < 0)
		{
			totalNetFTF.setForeground(Color.RED);
		}//if
		else
		{
			totalNetFTF.setForeground(Color.BLACK);
		}//else
		
	}//doSum()


	protected void do_vetAdFTF_propertyChange(PropertyChangeEvent evt) {
		doSum();
		if (vetAdNum < 0)
		{
			vetAdFTF.setForeground(Color.RED);
		}//if
		else
		{
			vetAdFTF.setForeground(Color.BLACK);
		}//else
	}
	
	protected void do_salaryFTF_propertyChange(PropertyChangeEvent evt) {
		doSum();
		if (salaryNum < 0)
		{
			salaryFTF.setForeground(Color.RED);
		}//if
		else
		{
			salaryFTF.setForeground(Color.BLACK);
		}//else
	}
	protected void do_pensionFTF_propertyChange(PropertyChangeEvent evt) {
		doSum();
		if (pensionNum < 0)
		{
			pensionFTF.setForeground(Color.RED);
		}//if
		else
		{
			pensionFTF.setForeground(Color.BLACK);
		}//else
	}
	protected void do_aliChFTF_propertyChange(PropertyChangeEvent evt) {
		doSum();
		if (aliChNum < 0)
		{
			aliChFTF.setForeground(Color.RED);
		}//if
		else
		{
			aliChFTF.setForeground(Color.BLACK);
		}//else
	}
	protected void do_unemployedFTF_propertyChange(PropertyChangeEvent evt) {
		doSum();
		if (unemployNum < 0)
		{
			unemployedFTF.setForeground(Color.RED);
		}//if
		else
		{
			unemployedFTF.setForeground(Color.BLACK);
		}//else
	}
	protected void do_otherIFTF_propertyChange(PropertyChangeEvent evt) {
		doSum();
		if (otherINum < 0)
		{
			otherIFTF.setForeground(Color.RED);
		}//if
		else
		{
			otherIFTF.setForeground(Color.BLACK);
		}//else
	}
	protected void do_housingFTF_propertyChange(PropertyChangeEvent evt) {
		doSum();

		housingFTF.setForeground(Color.RED);
	}
	protected void do_utilitiesFTF_propertyChange(PropertyChangeEvent evt) {
		doSum();
		
		utilitiesFTF.setForeground(Color.RED);
	}
	protected void do_insuranceFTF_propertyChange(PropertyChangeEvent evt) {
		doSum();
		
		insuranceFTF.setForeground(Color.RED);
	}
	protected void do_medicalFTF_propertyChange(PropertyChangeEvent evt) {
		doSum();
		
		medicalFTF.setForeground(Color.RED);
	}
	protected void do_foodFTF_propertyChange(PropertyChangeEvent evt) {
		doSum();
		
		foodFTF.setForeground(Color.RED);
	}
	protected void do_otherEFTF_propertyChange(PropertyChangeEvent evt) {
		doSum();

		otherEFTF.setForeground(Color.RED);
	}
	
	protected void do_spTotalChildren_stateChanged(ChangeEvent arg0) {
		int childVal = (Integer) spTotalChildren.getValue(); 
		if (childVal >= 1)
		{
			lblCName1.setEnabled(true);
			cName1TF.setEnabled(true);
			lblCGender1.setEnabled(true);
			cGender1CB.setEnabled(true);
			lblCBirthdate1.setEnabled(true);
			spCBirthdate1.setEnabled(true);
			lblCAge1.setEnabled(true);
			spCAge1.setEnabled(true);
			lblCClothes1.setEnabled(true);
			cClothes1CB.setEnabled(true);
			lblCShoes1.setEnabled(true);
			cShoes1CB.setEnabled(true);
			lblCGame1.setEnabled(true);
			listCGames1.setEnabled(true);
			lblCInterests1.setEnabled(true);
			listCInterests1.setEnabled(true);
		}//if
		else
		{
			lblCName1.setEnabled(false);
			cName1TF.setEnabled(false);
			lblCGender1.setEnabled(false);
			cGender1CB.setEnabled(false);
			lblCBirthdate1.setEnabled(false);
			spCBirthdate1.setEnabled(false);
			lblCAge1.setEnabled(false);
			spCAge1.setEnabled(false);
			lblCClothes1.setEnabled(false);
			cClothes1CB.setEnabled(false);
			lblCShoes1.setEnabled(false);
			cShoes1CB.setEnabled(false);
			lblCGame1.setEnabled(false);
			listCGames1.setEnabled(false);
			lblCInterests1.setEnabled(false);
			listCInterests1.setEnabled(false);
		}//else
		if (childVal >= 2)
		{
			lblCName2.setEnabled(true);
			cName2TF.setEnabled(true);
			lblCGender2.setEnabled(true);
			cGender2CB.setEnabled(true);
			lblCBirthdate2.setEnabled(true);
			spCBirthdate2.setEnabled(true);
			lblCAge2.setEnabled(true);
			spCAge2.setEnabled(true);
			lblCClothes2.setEnabled(true);
			cClothes2CB.setEnabled(true);
			lblCShoes2.setEnabled(true);
			cShoes2CB.setEnabled(true);
			lblCGame2.setEnabled(true);
			listCGames2.setEnabled(true);
			lblCInterests2.setEnabled(true);
			listCInterests2.setEnabled(true);
		}//if
		else
		{
			lblCName2.setEnabled(false);
			cName2TF.setEnabled(false);
			lblCGender2.setEnabled(false);
			cGender2CB.setEnabled(false);
			lblCBirthdate2.setEnabled(false);
			spCBirthdate2.setEnabled(false);
			lblCAge2.setEnabled(false);
			spCAge2.setEnabled(false);
			lblCClothes2.setEnabled(false);
			cClothes2CB.setEnabled(false);
			lblCShoes2.setEnabled(false);
			cShoes2CB.setEnabled(false);
			lblCGame2.setEnabled(false);
			listCGames2.setEnabled(false);
			lblCInterests2.setEnabled(false);
			listCInterests2.setEnabled(false);
		}//else
		if (childVal >= 3)
		{
			lblCName3.setEnabled(true);
			cName3TF.setEnabled(true);
			lblCGender3.setEnabled(true);
			cGender3CB.setEnabled(true);
			lblCBirthdate3.setEnabled(true);
			spCBirthdate3.setEnabled(true);
			lblCAge3.setEnabled(true);
			spCAge3.setEnabled(true);
			lblCClothes3.setEnabled(true);
			cClothes3CB.setEnabled(true);
			lblCShoes3.setEnabled(true);
			cShoes3CB.setEnabled(true);
			lblCGame3.setEnabled(true);
			listCGames3.setEnabled(true);
			lblCInterests3.setEnabled(true);
			listCInterests3.setEnabled(true);
		}//if
		else
		{
			lblCName3.setEnabled(false);
			cName3TF.setEnabled(false);
			lblCGender3.setEnabled(false);
			cGender3CB.setEnabled(false);
			lblCBirthdate3.setEnabled(false);
			spCBirthdate3.setEnabled(false);
			lblCAge3.setEnabled(false);
			spCAge3.setEnabled(false);
			lblCClothes3.setEnabled(false);
			cClothes3CB.setEnabled(false);
			lblCShoes3.setEnabled(false);
			cShoes3CB.setEnabled(false);
			lblCGame3.setEnabled(false);
			listCGames3.setEnabled(false);
			lblCInterests3.setEnabled(false);
			listCInterests3.setEnabled(false);
		}//else
	}
	protected void do_mnStart_actionPerformed(ActionEvent arg0) {
		Object [] options = {"Yes", "No"};
		int n = JOptionPane.showOptionDialog(this, "Are you sure?", "Start a new application?", JOptionPane.YES_NO_OPTION, 
				JOptionPane.QUESTION_MESSAGE, null, options, options[1]);
		if (n == JOptionPane.YES_OPTION)
		{
			EventQueue.invokeLater(new Runnable() {
				public void run() {
					try {
						VissicchioSACAPframe frame = new VissicchioSACAPframe();
						frame.setVisible(true);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
			this.dispose();
		}//if
	}
	protected void do_mntmExit_actionPerformed(ActionEvent e) {
		Object [] options = {"Yes", "No"};
		int n = JOptionPane.showOptionDialog(this, "Are you sure?", "Exit?", JOptionPane.YES_NO_OPTION, 
				JOptionPane.QUESTION_MESSAGE, null, options, options[1]);
		if (n == JOptionPane.YES_OPTION)
		{
			this.dispose();
		}//if
	}
	
	protected void do_mntmApplicant_actionPerformed(ActionEvent arg0) {
		JOptionPane.showMessageDialog(this, "Help for the Applicant Page \n"
				+ "\n Applicant's Name: Type in your last name then your first name"
				+ "\n Last 4 digits of your ssn: Type in the last 4 digits of your ssn, only numbers are accepted"
				+ "\n BirthDate: you must Click on the individual numbers in between the '/' than use the arrows."
				+ "\n Marital Status: Click the down arrow and select one of the choices"
				+ "\n Race: Click the down arrow and select one of the choices"
				+ "\n Gender: Click the down arrow and select one of the choices"
				+ "\n Phone Number: Type in your phone number, only numbers are accepted"
				+ "\n Street Address: Type in your street address"
				+ "\n City: Type in your city"
				+ "\n State: Type in your state"
				+ "\n Zip Code: Type in your zip code, only numbers are accepted"
				+ "\n Organization?: Click the down arrow and choose yes or no"
				+ "\n Digital Signature: Click the box and it will automatically perform the digital signature using your name"
				+ "\n \n You will need to specify total number of people in your household to make the information not grayed-out!"
				+ "\n Name: Type in the household member's name"
				+ "\n Relationship: Type in the household member's relationship with you"
				+ "\n Age: Type in the household member's age or use the arrows, must be over 14", "Help", JOptionPane.QUESTION_MESSAGE);
	}
	
	
	protected void do_mntmFinancial_actionPerformed(ActionEvent arg0) {
		JOptionPane.showMessageDialog(this, "Help for the Financial Page \n"
				+ "\n Type in the correct amount of each form of income and expense, only numbers are accepted"
				+ "\n This will be in USD and the totals as well as the net total will be automatically calculated for you"
				+ "\n With \"Other\" specify using the box below and hit the \"enter\" key after each one", "Help", JOptionPane.QUESTION_MESSAGE);
	}
	
	protected void do_mntmShopping_actionPerformed(ActionEvent arg0) {
		JOptionPane.showMessageDialog(this, "Help for the Shopping Page \n"
				+ "\n You will need to specify total number of people in your household to make the information not grayed-out!"
				+ "\n Child's First Name: Type in the child's first name"
				+ "\n Gender: Click the down arrow and choose one of the choices for your child's gender"
				+ "\n BirthDate: you must Click on the individual numbers in between the '/' than use the arrows."
				+ "\n Age: Type in the child's age or use the arrows, must be under 14"
				+ "\n Clothing Size: Click the down arrow and choose one of the choices for your child's clothing size"
				+ "\n Shoe Size: Click the down arrow and choose one of the choices for your child's shoe size"
				+ "\n Game Systems Owned: Click all that apply for the games system's the child owns"
				+ "\n Child's Interests: Click all that apply for the interests the child has", "Help", JOptionPane.QUESTION_MESSAGE);
	}
	protected void do_totalIncomeFTF_propertyChange(PropertyChangeEvent arg0) {
		doSum();
	}
	
	protected void do_totalExpensesFTF_propertyChange(PropertyChangeEvent evt) {
		doSum();
	}
}
