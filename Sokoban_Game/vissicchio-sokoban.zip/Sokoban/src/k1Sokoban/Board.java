package k1Sokoban;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import sf.Sound;
import sf.SoundFactory;
import hs.HighScores;
import hs.Record;

@SuppressWarnings({"serial","rawtypes", "unchecked"})
public class Board extends JPanel { 

    private final int OFFSET = 30 * 2;
    private final int SPACE = 20 * 2;
    private final int LEFT_COLLISION = 1;
    private final int RIGHT_COLLISION = 2;
    private final int TOP_COLLISION = 3;
    private final int BOTTOM_COLLISION = 4;

    private ArrayList walls = new ArrayList();
    private ArrayList baggs = new ArrayList();
    private ArrayList areas = new ArrayList();
    private Player soko;
    private int w = 0;
    private int h = 0;
    private boolean completed = false;
    
    private boolean inGame = false;
    private int moveCounter = 0;
    private long start;
    private long elapsed;
    
    private boolean randomizeFlag = false;
    
    public final static String DIR = "src/res/";
    public final static String COMPLETE = DIR + "mixkit-player-boost-recharging-2040.wav";
    public final static String BEGIN = DIR + "mixkit-winning-a-coin-video-game-2069.wav";
    public final static String MOVEMENT = DIR + "move.wav";
    public final static String AREA = DIR + "mixkit-bag-of-coins-touch-3187.wav";
	
    private Logo logo;
    
    private String name;
    
    
    private String level =
              "    ######\n"
            + "    ##   #\n"
            + "    ##$  #\n"
            + "  ####  $##\n"
            + "  ##  $ $ #\n"
            + "#### # ## #   ######\n"
            + "##   # ## #####  ..#\n"
            + "## $  $          ..#\n"
            + "###### ### #@##  ..#\n"
            + "    ##     #########\n"
            + "    ########\n";
    
    private String level2 =
            "    ######\n"
          + "    ##   #\n"
          + "    ## $ #\n"
          + "  #### $ ##\n"
          + "  ##    $ #\n"
          + "#### # ## #   ######\n"
          + "##  $#$## #####  ..#\n"
          + "##               ..#\n"
          + "###### ###$#@##  ..#\n"
          + "    ##     #########\n"
          + "    ########\n";
    
    private String level3 =
            "    ######\n"
          + "    ##   #\n"
          + "    ##   #\n"
          + "  ####  $##\n"
          + "  ##      #\n"
          + "#### #$## #   ######\n"
          + "##   # ##$#####  ..#\n"
          + "##  $  $        $..#\n"
          + "###### ### #@##  ..#\n"
          + "    ##     #########\n"
          + "    ########\n";
    
    private String level4 =
            "    ######\n"
          + "    ##   #\n"
          + "    ## $ #\n"
          + "  ####   ##\n"
          + "  ##   $  #\n"
          + "#### # ## #   ######\n"
          + "##   # ## #####  ..#\n"
          + "## $ $   $   $   ..#\n"
          + "###### ### #@##  ..#\n"
          + "    ##     #########\n"
          + "    ########\n";
    
    private String level5 =
            "    ######\n"
          + "    ##   #\n"
          + "    ## $ #\n"
          + "  #### $ ##\n"
          + "  ## $    #\n"
          + "#### # ## #   ######\n"
          + "##   # ## #####  ..#\n"
          + "## $    $       $..#\n"
          + "###### ### #@##  ..#\n"
          + "    ##     #########\n"
          + "    ########\n";
    
    private String level6 =
            "    ######\n"
          + "    ##   #\n"
          + "    ##$  #\n"
          + "  ####  $##\n"
          + "  ##      #\n"
          + "#### #$## #   ######\n"
          + "##   # ## ##### $..#\n"
          + "##               ..#\n"
          + "###### ###$#@## $..#\n"
          + "    ##     #########\n"
          + "    ########\n";
    
    private String level7 =
            "    ######\n"
          + "    ##   #\n"
          + "    ## $ #\n"
          + "  ####   ##\n"
          + "  ##   $  #\n"
          + "#### # ## #   ######\n"
          + "##   # ## ##### $..#\n"
          + "##              $..#\n"
          + "######$### #@## $..#\n"
          + "    ##     #########\n"
          + "    ########\n";
    
    //The remaining levels are challenge levels since they will have different area locations.
    private String level8 =
            "    ######\n"
          + "    ## . #\n"
          + "    ## $ #\n"
          + "  ####   ##\n"
          + "  ##   $  #\n"
          + "#### # #  #   ######\n"
          + "##  $# #  #####   .#\n"
          + "##.           $   .#\n"
          + "######$# #$#@##   .#\n"
          + "    ##  .  #########\n"
          + "    ########\n";
    
    private String level9 =
            "    ######\n"
          + "    ## . #\n"
          + "    ## $ #\n"
          + "  #### $ ##\n"
          + "  ## $   .#\n"
          + "#### # # ##   ######\n"
          + "##   # # ######.   #\n"
          + "## $    $       $ .#\n"
          + "###### # # #@##.   #\n"
          + "    ##  .  #########\n"
          + "    ########\n";
    
    private String level10 =
            "    ######\n"
          + "    ##.  #\n"
          + "    ##  $#\n"
          + "  ####$  ##\n"
          + "  ##     .#\n"
          + "####$# # ##   ######\n"
          + "##   # # ######.$  #\n"
          + "##    $           .#\n"
          + "######$# # #@##.   #\n"
          + "    ##  .  #########\n"
          + "    ########\n";
            
    private String[] levelArray = new String[10];
    private int totalLevels = levelArray.length;
    private int levelNum = 0;
    


    public Board() 
    {

        addKeyListener(new TAdapter());
        setFocusable(true);
        initWorld();
    }

    public int getBoardWidth() 
    {
        return this.w;
    }

    public int getBoardHeight() 
    {
        return this.h;
    }
    

    //swaps two given elements in an array
    public void swap(String array[], int a, int b)
    {
    	String temp = array[a];
        array[a] = array[b];
        array[b] = temp;
    }//swap
        
    //randomly shuffles the array
    public void shuffle(String array[])
    {
    	Random randomize = new Random();
        int n = array.length;
        for (int i = n - 1; i > 0; i--) 
        {
        	int j = randomize.nextInt(i + 1);

            //makes use of swap to swap array[i] with array[j]
            swap(array, i, j);
        }//for
    }//shuffle


    public final void initWorld() 
    {
    	//when you first initialize the game, put all levels within the array then go through the knuth shuffle to randomize the level you get.
    	if (randomizeFlag == false)
    	{
    		levelArray[0] = level;
    		levelArray[1] = level2;
    		levelArray[2] = level3;
    		levelArray[3] = level4;
    		levelArray[4] = level5;
    		levelArray[5] = level6;
    		levelArray[6] = level7;
    		levelArray[7] = level8;
    		levelArray[8] = level9;
    		levelArray[9] = level10;
    		this.shuffle(levelArray);
    		randomizeFlag = true;
    	}
        String currLevel = levelArray[levelNum];
        
        int x = OFFSET;
        int y = OFFSET;
        
        Wall wall;
        Baggage b;
        Area a;


        for (int i = 0; i < currLevel.length(); i++) 
        {

            char item = currLevel.charAt(i);

            if (item == '\n') 
            {
                y += SPACE;
                if (this.w < x) 
                {
                    this.w = x;
                }

                x = OFFSET;
            } 
            else if (item == '#') 
            {
                wall = new Wall(x, y);
                walls.add(wall);
                x += SPACE;
            } 
            else if (item == '$') 
            {
                b = new Baggage(x, y);
                baggs.add(b);
                x += SPACE;
            } 
            else if (item == '.') 
            {
                a = new Area(x, y);
                areas.add(a);
                x += SPACE;
            } 
            else if (item == '@') 
            {
                soko = new Player(x, y);
                x += SPACE;
            } 
            else if (item == ' ') 
            {
                x += SPACE;
            }

            h = y;
        }
    }

    public void buildWorld(Graphics g) 
    {
    	
        g.setColor(new Color(250, 240, 170));
        g.fillRect(0, 0, this.getWidth(), this.getHeight());

        ArrayList world = new ArrayList();
        world.addAll(walls);
        world.addAll(areas);
        world.addAll(baggs);
        world.add(soko);

        for (int i = 0; i < world.size(); i++) 
        {

            Actor item = (Actor) world.get(i);

            if ((item instanceof Player) || (item instanceof Baggage)) 
            {
                g.drawImage(item.getImage(), item.x() + 2, item.y() + 2, this);
            } 
            else 
            {
                g.drawImage(item.getImage(), item.x(), item.y(), this);
            }
            
            g.setColor(new Color(0, 0, 0));
            g.drawString("Instructions: Push all baggage to the diamond printed area.", 550, 100);
            g.drawString("Use the arrow keys to move around the board.", 550, 120);
            g.drawString("Press \"R\" to Restart the Level.", 550, 20);
            g.drawString("Press \"T\" to Try Another Level.", 550, 40);
            g.drawString("Press \"Q\" to Quit to Menu.", 550, 60);
            g.drawString("Move Counter: " + moveCounter, 550, 160);
            g.drawString("Seconds Elapsed: " + elapsed, 550, 180);

            if (completed) 
            {
                g.setColor(new Color(0, 0, 0));
                g.drawRect(20, 0, 75, 30);
                g.drawString("Completed", 25, 20);
            }

        }
    }
    
    public void showIntroScreen(Graphics g) 
    {
    	logo = new Logo(this.getWidth() / 2 - 220, this.getHeight() / 2 - 160);
    	Baggage coin = new Baggage(this.getWidth()/ 2 - 200, this.getHeight() / 2 + 34);
    	
    	g.setColor(new Color(250, 240, 170));
        g.setColor(Color.black);
        g.fillRect(0, 0, this.getWidth(), this.getHeight());
        g.drawImage(logo.getImage(), logo.x(), logo.y(), this);
        g.drawImage(coin.getImage(), coin.x(), coin.y(), this);
        g.drawImage(coin.getImage(), coin.x() + 365, coin.y(), this);
        g.drawImage(coin.getImage(), coin.x() + 26, coin.y() + 81, this);
        g.drawImage(coin.getImage(), coin.x() + 26 + 315, coin.y() + 81, this);
        g.drawImage(coin.getImage(), coin.x() - 46, coin.y() + 162, this);
        g.drawImage(coin.getImage(), coin.x() - 44 + 452, coin.y() + 162, this);
        String s = "Press Space to start.";
        String s2 = "Press \"Q\" to quit.";
        String hs = "Press \"S\" to check Scores.";
        Font font = new Font("Helvetica", Font.BOLD, 32);
        FontMetrics metr = this.getFontMetrics(font);
        g.setColor(Color.white);
        g.drawRect(logo.x() - 20, logo.y() - 20, 490, 115);
        g.setFont(font);
        g.drawString(s, (this.getWidth() - metr.stringWidth(s)) / 2, this.getWidth() / 2 - 100);
        g.drawString(s2, (this.getWidth() - metr.stringWidth(s2)) / 2, this.getWidth() / 2 - 20);
        g.drawString(hs, (this.getWidth() - metr.stringWidth(hs)) / 2, this.getWidth() / 2 + 60);
        
    }
    
    public void showEndScreen(Graphics g) 
    {
    	g.setColor(new Color(250, 240, 170));
        g.setColor(Color.black);
        g.fillRect(0, 0, this.getWidth(), this.getHeight());
        
        String s = "Press Space to restart game.";
        String s2 = "Press \"Q\" to quit.";
        String hs = "Press \"S\" to check Scores.";
        String title = "Complete";
        String info = "Moves: " + moveCounter + ".";
        String info2 = "Time: " + elapsed + " seconds.";
        Font font = new Font("Helvetica", Font.BOLD, 32);
        Font fontTitle = new Font("Helvetica", Font.BOLD, 100);
        FontMetrics metr = this.getFontMetrics(font);
        FontMetrics metr2 = this.getFontMetrics(fontTitle);

        g.setColor(Color.white);
        g.setFont(fontTitle);
        g.drawString(title, (this.getWidth() - metr2.stringWidth(title)) / 2, this.getHeight() / 2 - 80);
        
        g.setColor(Color.white);
        g.setFont(font);
        g.drawString(info, (this.getWidth() - metr.stringWidth(info)) / 2, this.getWidth() / 2 - 120);
        g.drawString(info2, (this.getWidth() - metr.stringWidth(info2)) / 2, this.getWidth() / 2 - 160);
        g.drawString(s, (this.getWidth() - metr.stringWidth(s)) / 2, this.getWidth() / 2 - 40);
        g.drawString(s2, (this.getWidth() - metr.stringWidth(s2)) / 2, this.getWidth() / 2);
        g.drawString(hs, (this.getWidth() - metr.stringWidth(hs)) / 2, this.getWidth() / 2 + 40);
    }
    
    public void highScores(ActionEvent arg0) 
    {
    	BufferedReader reader;
    	
    	try {
			reader = new BufferedReader(new FileReader("src/res/highscores.txt"));
			
			String line = reader.readLine();
			String scoreList = "";
			int lineCount = 0;
			
			/*It will only show the top 5 scores*/
			while(line != null && lineCount < 5) {
				System.out.println(line);
				scoreList = scoreList + line + "\n";
				line = reader.readLine();
				lineCount++;
			}
			JOptionPane.showMessageDialog(this, scoreList, "Fastest Times", JOptionPane.PLAIN_MESSAGE);
			reader.close();
		} 
    	
    	/*
    	   If a player tries to check the scores before writing their first score, this will add a record and
    	   then call itself to read that record using the file that is now created.
    	*/
    	catch (FileNotFoundException e)
    	{
    		addRecord("JAV", 40);
    		highScores(null);
    		
    	}
    	catch (IOException e) {
			e.printStackTrace();
		}
    }
    
    public void addRecord(String newName, int score)
    {
		HighScores highscores = new HighScores("src/res/highscores.txt");
		ArrayList<Record> records = highscores.load();
		
		/*If we want to clear the records*/
		//records.clear();
		
		records.add(new Record(newName, score));
		
		int count = highscores.save();
		
		System.out.println("saved:");
		System.out.println(highscores);
		System.out.println(count+" records");
    }

    @Override
    public void paint(Graphics g) 
    {
    	/*
    	  This will paint the graphics based on the values of the boolean variables inGame and completed.
    	  These graphics make up the three different phases of the game.
    	*/
        super.paint(g);
        if (inGame)
        {
        	this.elapsed = (System.currentTimeMillis() - this.start)/1000;
        	buildWorld(g);
        }
        else if (completed)
        {
        	Sound soundComplete = SoundFactory.getInstance(COMPLETE);
      		SoundFactory.play(soundComplete);
      		System.out.println("complete");
        	showEndScreen(g);
        	restartLevel();
        }
        else
        {
        	showIntroScreen(g);
        }
    }

    class TAdapter extends KeyAdapter 
    {
        @Override
        public void keyPressed(KeyEvent e) 
        {
        	int key = e.getKeyCode();
        	
        	if (inGame) {
            if (key == KeyEvent.VK_LEFT) {
            	Sound soundMovement = SoundFactory.getInstance(MOVEMENT);
          		SoundFactory.play(soundMovement);
            	moveCounter++;
                if (checkWallCollision(soko, LEFT_COLLISION)) 
                {
                    return;
                }

                if (checkBagCollision(LEFT_COLLISION)) 
                {
                    return;
                }

                soko.move(-SPACE, 0);

            } 
            else if (key == KeyEvent.VK_RIGHT) 
            {
            	Sound soundMovement = SoundFactory.getInstance(MOVEMENT);
            	SoundFactory.play(soundMovement);
            	moveCounter++;
                if (checkWallCollision(soko, RIGHT_COLLISION)) 
                {
                    return;
                }

                if (checkBagCollision(RIGHT_COLLISION)) {
                    return;
                }

                soko.move(SPACE, 0);

            } 
            else if (key == KeyEvent.VK_UP) 
            {
            	Sound soundMovement = SoundFactory.getInstance(MOVEMENT);
            	SoundFactory.play(soundMovement);
            	moveCounter++;
                if (checkWallCollision(soko, TOP_COLLISION)) 
                {
                    return;
                }

                if (checkBagCollision(TOP_COLLISION)) 
                {
                    return;
                }

                soko.move(0, -SPACE);

            } 
            else if (key == KeyEvent.VK_DOWN) 
            {
            	Sound soundMovement = SoundFactory.getInstance(MOVEMENT);
            	SoundFactory.play(soundMovement);
            	moveCounter++;
                if (checkWallCollision(soko, BOTTOM_COLLISION)) 
                {
                    return;
                }

                if (checkBagCollision(BOTTOM_COLLISION)) 
                {
                    return;
                }

                soko.move(0, SPACE);

            } 
            else if (key == KeyEvent.VK_R) 
            {
            	//time and movement will NOT reset since it will cause people to cheat by resetting the time each time they mess up.
                restartLevel();
            }
        	else if (key == KeyEvent.VK_T) 
        	{
        		//time and movement will reset since you are trying out a new layout.
        		moveCounter = 0;
        		start = System.currentTimeMillis();
        		if (levelNum < totalLevels -1)
        		{
        			levelNum++;
        		}
        		else
        		{
        			levelNum = 0;
        		}
                restartLevel();
            }
            else if (key ==  KeyEvent.VK_Q)
            {
                inGame = false;
                restartLevel();
            }
        	}//inGame
        	
        	else if (completed) 
        	{
            	if (key ==  KeyEvent.VK_Q){
            		completed = false;
            		inGame = false;
            		repaint();
                  }
            	else if (key == KeyEvent.VK_SPACE) 
            	{
            		completed = false;
            		inGame = true;
            		start = System.currentTimeMillis();
            		moveCounter = 0;
            		repaint();
            		
                }
            	if (key == KeyEvent.VK_S)
            	{
            		highScores(null);
            	}
                return;
            }
        	
        	else
            {
              if (key ==  KeyEvent.VK_SPACE)
              {
            	Sound soundStart = SoundFactory.getInstance(BEGIN);
          		SoundFactory.play(soundStart);
          		try {
					TimeUnit.SECONDS.sleep(1);
				} 
          		catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
                inGame = true;
                start = System.currentTimeMillis();
                moveCounter = 0;
                
              }
              else if (key ==  KeyEvent.VK_Q)
              {
                  System.exit(0);
              }
              else if (key == KeyEvent.VK_S) 
              {
            	  highScores(null);
              }
            }
        	

            repaint();
        }
    }

    private boolean checkWallCollision(Actor actor, int type) 
    {

        if (type == LEFT_COLLISION) 
        {

            for (int i = 0; i < walls.size(); i++) 
            {
                Wall wall = (Wall) walls.get(i);
                if (actor.isLeftCollision(wall)) 
                {
                    return true;
                }
            }
            return false;

        } 
        else if (type == RIGHT_COLLISION) 
        {

            for (int i = 0; i < walls.size(); i++) 
            {
                Wall wall = (Wall) walls.get(i);
                if (actor.isRightCollision(wall)) 
                {
                    return true;
                }
            }
            return false;

        } 
        else if (type == TOP_COLLISION) 
        {

            for (int i = 0; i < walls.size(); i++) 
            {
                Wall wall = (Wall) walls.get(i);
                if (actor.isTopCollision(wall)) 
                {
                    return true;
                }
            }
            return false;

        } 
        else if (type == BOTTOM_COLLISION) 
        {

            for (int i = 0; i < walls.size(); i++) 
            {
                Wall wall = (Wall) walls.get(i);
                if (actor.isBottomCollision(wall)) 
                {
                    return true;
                }
            }
            return false;
        }
        return false;
    }

    private boolean checkBagCollision(int type) 
    {

        if (type == LEFT_COLLISION) 
        {

            for (int i = 0; i < baggs.size(); i++) 
            {

                Baggage bag = (Baggage) baggs.get(i);
                if (soko.isLeftCollision(bag)) 
                {

                    for (int j=0; j < baggs.size(); j++) 
                    {
                        Baggage item = (Baggage) baggs.get(j);
                        if (!bag.equals(item)) 
                        {
                            if (bag.isLeftCollision(item)) 
                            {
                                return true;
                            }
                        }
                        if (checkWallCollision(bag, LEFT_COLLISION)) 
                        {
                            return true;
                        }
                    }
                    bag.move(-SPACE, 0);
                    isCompleted();
                }
            }
            return false;

        } 
        else if (type == RIGHT_COLLISION) 
        {

            for (int i = 0; i < baggs.size(); i++) 
            {

                Baggage bag = (Baggage) baggs.get(i);
                if (soko.isRightCollision(bag)) 
                {
                    for (int j=0; j < baggs.size(); j++) 
                    {

                        Baggage item = (Baggage) baggs.get(j);
                        if (!bag.equals(item)) 
                        {
                            if (bag.isRightCollision(item)) 
                            {
                                return true;
                            }
                        }
                        if (checkWallCollision(bag, RIGHT_COLLISION)) 
                        {
                            return true;
                        }
                    }
                    bag.move(SPACE, 0);
                    isCompleted();                   
                }
            }
            return false;

        } 
        else if (type == TOP_COLLISION) 
        {

            for (int i = 0; i < baggs.size(); i++) 
            {

                Baggage bag = (Baggage) baggs.get(i);
                if (soko.isTopCollision(bag)) 
                {
                    for (int j = 0; j < baggs.size(); j++) 
                    {

                        Baggage item = (Baggage) baggs.get(j);
                        if (!bag.equals(item)) {
                            if (bag.isTopCollision(item)) 
                            {
                                return true;
                            }
                        }
                        if (checkWallCollision(bag, TOP_COLLISION)) 
                        {
                            return true;
                        }
                    }
                    bag.move(0, -SPACE);
                    isCompleted();
                }
            }

            return false;

        } 
        else if (type == BOTTOM_COLLISION) 
        {
        
            for (int i = 0; i < baggs.size(); i++) 
            {

                Baggage bag = (Baggage) baggs.get(i);
                if (soko.isBottomCollision(bag)) 
                {
                    for (int j = 0; j < baggs.size(); j++) 
                    {

                        Baggage item = (Baggage) baggs.get(j);
                        if (!bag.equals(item)) 
                        {
                            if (bag.isBottomCollision(item)) 
                            {
                                return true;
                            }
                        }
                        if (checkWallCollision(bag, BOTTOM_COLLISION)) 
                        {
                            return true;
                        }
                    }
                    bag.move(0, SPACE);
                    isCompleted();
                }
            }
        }

        return false;
    }

    /*
       Will check for each baggage being put into an area so that each one creates sound effects without them repeating on every repaint.
    */
    int complFlag1 = 0;
    int complFlag2 = 0;
    int complFlag3 = 0;
    int complFlag4 = 0;
    int complFlag5 = 0;
    int complFlag6 = 0;
    public void isCompleted() 
    {

        int num = baggs.size();
        int compl = 0;

        for (int i = 0; i < num; i++) {
            Baggage bag = (Baggage) baggs.get(i);
            for (int j = 0; j < num; j++) {
                Area area = (Area) areas.get(j);
                if (bag.x() == area.x() && bag.y() == area.y()) 
                {
                    compl += 1;
                    if (complFlag1 == 0)
                    {
                    	complFlag1 += 1;
                    	Sound soundArea = SoundFactory.getInstance(AREA);
                  		SoundFactory.play(soundArea);
                    }
                    if (complFlag2 == 0 && compl == 2)
                    {
                    	complFlag2 += 1;
                    	Sound soundArea = SoundFactory.getInstance(AREA);
                  		SoundFactory.play(soundArea);
                    }
                    if (complFlag3 == 0 && compl == 3)
                    {
                    	complFlag3 += 1;
                    	Sound soundArea = SoundFactory.getInstance(AREA);
                  		SoundFactory.play(soundArea);
                    }
                    if (complFlag4 == 0 && compl == 4)
                    {
                    	complFlag4 += 1;
                    	Sound soundArea = SoundFactory.getInstance(AREA);
                  		SoundFactory.play(soundArea);
                    }
                    if (complFlag5 == 0 && compl == 5)
                    {
                    	complFlag5 += 1;
                    	Sound soundArea = SoundFactory.getInstance(AREA);
                  		SoundFactory.play(soundArea);
                    }
                }
            }
        }

        if (compl == num) 
        {
        	repaint();
        	
        	/*This is where the player is prompted to put in their name*/
        	name = " ";
        	name = JOptionPane.showInputDialog(this, "Enter your name");
    		System.out.println(name);
    		//No name input will result in AAA similar to old time arcade games
        	if (name == null || name.length() == 0)
        	{
        		name = "AAA";
        	}
        	name = name.substring(0, Math.min(name.length(), 3)).toUpperCase();
        	
        	//this will fill in A for the rest of the chars similar to old time arcade games
        	while (name.length() < 3)
        	{
        		name = name + "A";
        	}
        	addRecord(name, (int) elapsed);
        	
        	//After repaint it will bring us to the end screen.
            completed = true;
            inGame = false;
            repaint();
        }
    }

    public void restartLevel() 
    {
    	//clear and reset values so that the game can be replayed
        areas.clear();
        baggs.clear();
        walls.clear();
        initWorld();
        if (completed == true) 
        {
        	start = System.currentTimeMillis();
        	moveCounter = 0;
        }
        complFlag1 = 0;
        complFlag2 = 0;
        complFlag3 = 0;
        complFlag4 = 0;
        complFlag5 = 0;
        complFlag6 = 0;
    }
}