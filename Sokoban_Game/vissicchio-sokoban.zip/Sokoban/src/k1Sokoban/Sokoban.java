package k1Sokoban;

import javax.swing.JFrame;

import sf.Sound;
import sf.SoundFactory;

@SuppressWarnings("serial")
public final class Sokoban extends JFrame {

    private final int OFFSET = 30 * 2;

    public Sokoban() 
    {
        InitUI();
    }

    public void InitUI() 
    {
        Board board = new Board();
        add(board);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(board.getBoardWidth() + OFFSET,
                board.getBoardHeight() + 2*OFFSET);
        setResizable(false);
        setLocationRelativeTo(null);
        setTitle("Sokoban");
    }


    public static void main(String[] args) 
    {
        Sokoban sokoban = new Sokoban();
        sokoban.setVisible(true);
        String MUSIC = "src/res/music3.wav";
        Sound music = SoundFactory.getInstance(MUSIC);
        SoundFactory.play(music, 99);
    }
}